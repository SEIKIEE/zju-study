
#include "genCode.hpp"

int main(int argc, const char* argv[])
{
    buildCode(argv[1],argv[2]);
    return 0;
}
