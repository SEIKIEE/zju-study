#ifndef _PARSE_H_
#define _PARSE_H_

#include "global.h"

SyntaxTree parse(void);

#endif
