
#ifndef visual_h
#define visual_h
#include "global.h"

void showSyntaxTree(SyntaxTree root);

#endif
