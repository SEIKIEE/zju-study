./complier [源代码文件]

./complier test.pas



输出：

token序列：tokens.txt

语法树：syntaxTree.txt

中间代码：ircode.txt