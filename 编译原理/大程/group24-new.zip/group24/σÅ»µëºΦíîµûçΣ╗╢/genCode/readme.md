./genCode [中间代码文件] [MIPS32指令序列文件]

./genCode ircode.txt a.asm



输出：MIPS32指令序列文件