#include "analyze.h"
#include<sstream>

Analyzer::Analyzer(SyntaxTree *node)
{
	root = node;
	Blocks = 1;
	loop_count = 0;
	success_flag = true;
	buildSymTab(root);
	success_flag &= my_symtab.callUndefinedFunc();
}

void Analyzer::buildSymTab(SyntaxTree *node)
{
	if (node == NULL)
		return;

	if (node->type == "declaration") {
		analyze_declaration(node);
		return;
	}
	else if (node->type == "function_definition") {
		analyze_function_definition(node);
		return;
	}
	else if (node->type == "statement") {
		analyze_statement(node);
		return;
	}

	if (node != NULL) {
		for (auto son : node->sons) {
			buildSymTab(son);
		}
	}
}

/*************************
** ��������������
*************************/

// �������������
void Analyzer::analyze_declaration_list(SyntaxTree *node)
{
	//cout << "analyze_declaration_list" << endl;
	// declaration_list -> declaration_list declaration
	if (node->sons.size() > 1) {
		analyze_declaration_list(node->sons.front());
		analyze_declaration(node->sons.back());
	}
	// init_declarator_list -> init_declarator
	else
		analyze_declaration(node->sons.back());
}

// �����������
void Analyzer::analyze_declaration(SyntaxTree *node)
{
	//cout << "analyze_declaration" << endl;
	// declaration -> declaration_specifiers init_declarator_list ";"
	SyntaxTree *declaration_specifiers = node->sons.front();
	string type = analyze_declaration_specifiers(declaration_specifiers);	// ��������
	analyze_init_declarator_list(type, node->sons.at(1));					// �����б�
	return;
}

// ������������е�����
std::string Analyzer::analyze_declaration_specifiers(SyntaxTree *node)
{
	//cout << "analyze_declaration_specifiers" << endl;
	std::string res = "";
	SyntaxTree *type_specifier;
	std::string Base = "";
	int Sig = 0, Unsig = 0, Long = 0, Short = 0, Type = 0;
	// declaration_specifiers -> type_specifier declaration_specifiers
	while (node->sons.size() != 1) {
		type_specifier = node->sons.front();
		SyntaxTree *next = node->sons.at(1);
		std::string ts = type_specifier->sons.front()->type;
		if (ts == "SIGNED")
			Sig++;
		else if (ts == "UNSIGNED")
			Unsig++;
		else if (ts == "SHORT")
			Short++;
		else if (ts == "LONG")
			Long++;
		else {
			if (Base != "")
				res += " ";
			Base = ts;
			res = res + ts;
			Type++;
		}
		node = next;
	}
	// declaration_specifiers -> type_specifier
	type_specifier = node->sons.front();
	std::string ts = type_specifier->sons.front()->type;
	if (ts == "SIGNED")
		Sig++;
	else if (ts == "UNSIGNED")
		Unsig++;
	else if (ts == "SHORT")
		Short++;
	else if (ts == "LONG")
		Long++;
	else {
		if (Base != "")
			res += " ";
		Base = ts;
		res = res + ts;
		Type++;
	}
	// ������������
	for (int i = 0; i < Long; ++i) {
		res = "LONG " + res;
	}
	for (int i = 0; i < Short; ++i) {
		res = "SHORT " + res;
	}
	for (int i = 0; i < Unsig; ++i) {
		res = "UNSIGNED " + res;
	}
	for (int i = 0; i < Sig; ++i) {
		res = "SIGNED " + res;
	}
	// Error
	if (Sig > 1 || Unsig > 1 || Short > 1 || Long > 2 || Type > 1 || (Short > 0 && Long > 0) || (Sig > 0 && Unsig > 0)) {
		res = "[Error] type \"" + res + "\" not allowed";
	}
	else if (Base == "") {
		res = res + "INT";
	}
	else if (Base == "VOID") {
		if (Sig || Unsig || Short || Long) {
			res = "[Error] type \"" + res + "\" not allowed";
		}
	}
	else if (Base == "CHAR") {
		if (Short || Long) {
			res = "[Error] type \"" + res + "\" not allowed";
		}
	}
	else if (Base == "BOOL") {
		if (Short || Long || Sig || Unsig) {
			res = "[Error] type \"" + res + "\" not allowed";
		}
	}
	else if (Base == "FLOAT") {
		if (Short || Long || Sig || Unsig) {
			res = "[Error] type \"" + res + "\" not allowed";
		}
	}
	else if (Base == "DOUBLE") {
		if (Sig || Unsig || Short || Long > 1) {
			res = "[Error] type \"" + res + "\" not allowed";
		}
	}
	return res;
}

// ������ʼ���б�
void Analyzer::analyze_init_declarator_list(string type, SyntaxTree *node)
{
	//cout << "analyze_init_declarator_list" << endl;
	// init_declarator_list -> init_declarator_list "," init_declarator
	if (node->sons.size() > 1) {
		analyze_init_declarator_list(type, node->sons.front());
		analyze_init_declarator(type, node->sons.back());
	}
	// init_declarator_list -> init_declarator
	else {
		analyze_init_declarator(type, node->sons.front());
	}
	return;
}

// ���������еı�ʶ���Լ���ʼ��
void Analyzer::analyze_init_declarator(std::string type, SyntaxTree *node)
{
	//cout << "analyze_init_declarator" << endl;
	std::string err = "[Error]";
	varNode tempNode;
	// init_declarator -> declarator
	if (node->sons.size() == 1) {
		SyntaxTree *declarator = node->sons.front();
		// declarator -> IDENTIFIER
		if (declarator->sons.size() == 1) {	// ��������
			SyntaxTree *IDENTIFIER = declarator->sons.front();
			string varName = IDENTIFIER->attributes["value"];	// ��������
			if (type == "VOID") {
				cerr << "[Error] variable \"" << varName << "\" declared void" << endl;
				success_flag = false;
				return;
			}
			if (type.compare(0, err.length(), err) == 0) {
				cerr << type << " in declaration of variable \"" << varName << "\"" << endl;
				success_flag = false;
				return;
			}
			if (my_symtab.curBlockLookup(varName)) {
				cerr << "[Error] redeclaration of \"" << varName << "\"" << endl;
				success_flag = false;
				return;
			}
			if (my_symtab.lookup(varName).isFuncNode) {
				cerr << "[Error] redeclaration of \"" << varName << "\"" << endl;
				success_flag = false;
				return;
			}
			// �½����ű���
			idNode v;
			v.setVar(varName, type);
			my_symtab.insert(varName, v);
		}
		else if (declarator->sons.size() == 3) {
			// direct_declarator -> IDENTIFIER "[" "]"
			if (declarator->sons.back()->type == "]") {	// ��������
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				string arrName = IDENTIFIER->attributes["value"];	// ��������
				// û�г�ʼ����Ҳû�������С������
				std::cerr << "[Error] array \"" << arrName << "\" declared without either initializer or array size" << std::endl;
				success_flag = false;
				return;
			}
			// direct_declarator -> IDENTIFIER "(" ")"
			else {	// ��������
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				std::string funcName = IDENTIFIER->attributes["value"];	// ��������
				if (type.compare(0, err.length(), err) == 0) {
					std::cerr << type << " in declaration of array \"" << funcName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.curBlockLookup(funcName)) {
					std::cerr << "[Error] redeclaration of \"" << funcName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// �½����ű���
				idNode f;
				varNode tvar;
				tvar.setVarNode("", "VOID");	// ��������
				vector<varNode> param_list;
				param_list.push_back(tvar);
				f.setFunc(funcName, type, param_list);
				my_symtab.insert(funcName, f);
			}
		}
		else {
			// declarator -> IDENTIFIER "[" CONSTANT_DEC "]"
			if (declarator->sons.back()->type == "]") {	// ��������
				varNode constant; 
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				string arrName = IDENTIFIER->attributes["value"];
				constant.setVarNode(declarator->sons[2]->attributes["value"], "CONSTANT INT");
				if (constant.varname.front() == '-') {
					std::cerr << "[Error] array \"" << arrName << "\" declared with negative length" << std::endl;
					success_flag = false;
					return;
				}
				if (type == "VOID") {
					std::cerr << "[Error] array \"" << arrName << "\" declared void" << std::endl;
					success_flag = false;
					return;
				}
				if (type.compare(0, err.length(), err) == 0) {
					std::cerr << type << " in declaration of array \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.curBlockLookup(arrName)) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.lookup(arrName).isFuncNode) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// ���ű��½���
				idNode a;
				a.setArray(arrName, type, std::stoi(constant.varname));
				my_symtab.insert(arrName, a);
				// �м����
				string temp_var = inter_code.gen_temp_name();
				string map_arr = my_symtab.mapVarName(arrName);
				inter_code.create_code_assign(temp_var, constant.varname);	// temp_var := constant
				inter_code.create_code_memory(map_arr, temp_var);			// DEC map_arr[temp_var]
				inter_code.free_temp_name(temp_var);
				inter_code.free_temp_name(constant.varname);
			}
			// declarator -> IDENTIFIER "(" parameter_list ")"
			else if (declarator->sons.at(2)->type == "parameter_list") {	// ��������
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				string funcName = IDENTIFIER->attributes["value"];				// ��������
				vector<varNode> paraList = analyze_parameter_list(declarator->sons.at(2));
				if (type.compare(0, err.length(), err) == 0) {
					std::cerr << type << " in declaration of function \"" << funcName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.curBlockLookup(funcName)) {
					std::cerr << "[Error] redeclaration of \"" << funcName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// �½����ű���
				idNode f;
				f.setFunc(funcName, type, paraList);
				my_symtab.insert(funcName, f);
			}
		}
	}
	// init_declarator -> declarator "=" initializer
	else if (node->sons.size() == 3) {
		SyntaxTree *declarator = node->sons.front();
		SyntaxTree *initializer = node->sons.back();

		// declarator -> IDENTIFIER
		if (declarator->sons.size() == 1) {		// ��������
			SyntaxTree *IDENTIFIER = declarator->sons.front();
			string varName = IDENTIFIER->attributes["value"];
			if (type == "VOID") {
				std::cerr << "[Error] variable \"" << varName << "\" declared void" << std::endl;
				success_flag = false;
				return;
			}
			if (type.compare(0, err.length(), err) == 0) {
				std::cerr << type << " in declaration of variable \"" << varName << "\"" << std::endl;
				success_flag = false;
				return;
			}
			if (my_symtab.curBlockLookup(varName)) {
				std::cerr << "[Error] redeclaration of \"" << varName << "\"" << std::endl;
				success_flag = false;
				return;
			}
			if (my_symtab.lookup(varName).isFuncNode) {
				std::cerr << "[Error] redeclaration of \"" << varName << "\"" << std::endl;
				success_flag = false;
				return;
			}
			// initializer -> expression
			if (initializer->sons.size() == 1) {
				varNode init = analyze_expression(initializer->sons.front());	// ... init
				// �������
				tempNode.setVarNode("", type);
				if (!looseTypeCheck(tempNode, init)) {
					std::cerr << "[Error] type mismatch in declaration of \"" << varName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// ���ű��½���
				idNode v;
				v.setVar(varName, type);
				my_symtab.insert(varName, v);
				// �м����
				string map_var = my_symtab.mapVarName(varName);
				inter_code.create_code_assign(map_var, init.varname);			// map_var := init
				inter_code.free_temp_name(init.varname);
			}
			// initializer -> "{" initializer_list "}"
			// initializer -> "{" initializer_list "," "}"
			else {
				// �����������б���ʼ��
				std::cerr << "[Error] in initialization of \"" << varName << "\"" << std::endl;
				success_flag = false;
				return;
				}
			}
		else if (declarator->sons.size() == 3) {
			// direct_declarator -> IDENTIFIER "[" "]"
			if (declarator->sons.back()->type == "]") { // ��������
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				string arrName = IDENTIFIER->attributes["value"];
				if (type == "VOID") {
					std::cerr << "[Error] array \"" << arrName << "\" declared void" << std::endl;
					success_flag = false;
					return;
				}
				if (type.compare(0, err.length(), err) == 0) {
					std::cerr << type << " in declaration of array \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.curBlockLookup(arrName)) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.lookup(arrName).isFuncNode) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}

				// initializer -> expression
				if (initializer->sons.size() == 1) {
					std::cerr << "[Error] array must be initialized with a brace - enclosed initializer, in declaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// initializer -> "{" initializer_list "}"
				// initializer -> "{" initializer_list "," "}"
				else {
					// initializer_list -> expression
					// initializer_list -> initializer_list "," expression
					SyntaxTree *initializer_list = initializer->sons.at(1);
					varNode init;
					vector<string> init_name;
					tempNode.setVarNode("", type);
					// ��������¼��ʼֵ
					while (initializer_list->sons.size() > 1) {
						init = analyze_expression(initializer_list->sons.back());	// ... init
						if (!looseTypeCheck(tempNode, init)) {	// ���ͼ��
							std::cerr << "[Error] type mismatch in declaration of \"" << arrName << "\"" << std::endl;
							success_flag = false;
							for (int i = init_name.size() - 1; i >= 0; --i)
								inter_code.free_temp_name(init_name[i]);
							return;
						}
						init_name.push_back(init.varname);
						initializer_list = initializer_list->sons.front();	// ����
					}
					init = analyze_expression(initializer_list->sons.back());	// ... init
					if (!looseTypeCheck(tempNode, init)) {	// ���ͼ��
						std::cerr << "[Error] type mismatch in declaration of \"" << arrName << "\"" << std::endl;
						success_flag = false;
						for (int i = init_name.size() - 1; i >= 0; --i)
							inter_code.free_temp_name(init_name[i]);
						return;
					}
					init_name.push_back(init.varname);
					// �½����ű���
					idNode a;
					a.setArray(arrName, type, init_name.size());
					my_symtab.insert(arrName, a);
					// �м����
					string map_arr = my_symtab.mapVarName(arrName);
					string temp1 = inter_code.gen_temp_name(), 
						temp2 = inter_code.gen_temp_name();
					inter_code.create_code_const_assign(temp1, to_string(init_name.size()));				// temp1 := arr_size
					inter_code.create_code_const_assign(temp2, to_string(inter_code.get_type_size(type)));	// temp2 := type_size
					inter_code.create_code_op(temp1, temp1, temp2, "*");		// temp1 := temp1 * temp2
					inter_code.create_code_memory(map_arr, temp1);				// DEC map_arr[temp1]
					inter_code.create_code_assign(temp1, map_arr);				// temp1 := map_arr
					for (int i = init_name.size() - 1; i >= 0; --i) {
						inter_code.create_code_store(temp1, init_name[i]);		// *temp1 := init
						inter_code.create_code_op(temp1, temp1, temp2, "+");	// temp1 := temp1 + temp2
						inter_code.free_temp_name(init_name[i]);
					}
					inter_code.free_temp_name(temp1);
					inter_code.free_temp_name(temp2);
				}
			}
			// direct_declarator -> IDENTIFIER "(" ")"
			else {
				std::cerr << "[Error] assignment to function" << std::endl;
				success_flag = false;
				return;
			}
		}
		else {
			// declarator -> IDENTIFIER "[" expression "]"
			if (declarator->sons.back()->type == "]") {
				varNode constant = analyze_expression(declarator->sons.at(2));	// ... constant
				SyntaxTree *IDENTIFIER = declarator->sons.front();
				string arrName = IDENTIFIER->attributes["value"];
				// Error
				string c = "CONSTANT";
				if (constant.vartype.compare(0, c.length(), c) != 0) {
					std::cerr << "[Error] array \"" << arrName << "\" declared with no constant length" << std::endl;
					success_flag = false;
					return;
				}
				if (constant.varname.front() == '-') {
					std::cerr << "[Error] array \"" << arrName << "\" declared with negative length" << std::endl;
					success_flag = false;
					return;
				}
				if (type == "VOID") {
					std::cerr << "[Error] array \"" << arrName << "\" declared void" << std::endl;
					success_flag = false;
					return;
				}
				if (type.compare(0, err.length(), err) == 0) {
					std::cerr << type << " in declaration of array \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.curBlockLookup(arrName)) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				if (my_symtab.lookup(arrName).isFuncNode) {
					std::cerr << "[Error] redeclaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// initializer -> expression
				if (initializer->sons.size() == 1) {
					std::cerr << "[Error] array must be initialized with a brace - enclosed initializer, in declaration of \"" << arrName << "\"" << std::endl;
					success_flag = false;
					return;
				}
				// initializer -> "{" initializer_list "}"
				// initializer -> "{" initializer_list "," "}"
				else {
					// initializer_list -> expression
					// initializer_list -> initializer_list "," expression
					SyntaxTree *initializer_list = initializer->sons.at(1);
					vector<string> init_name;
					varNode init;
					int arr_size = stoi(constant.varname);
					tempNode.setVarNode("", type);
					while (initializer_list->sons.size() > 1) {
						init = analyze_expression(initializer_list->sons.back());	// ... init
						if (!looseTypeCheck(tempNode, init)) {
							std::cerr << "[Error] type mismatch in declaration of \"" << arrName << "\"" << std::endl;
							success_flag = false;
							for (int i = init_name.size() - 1; i >= 0; --i)
								inter_code.free_temp_name(init_name[i]);
							return;
						}
						init_name.push_back(init.varname);
						initializer_list = initializer_list->sons.front();	// ����
					}
					init = analyze_expression(initializer_list->sons.back());	// ... init
					if (!looseTypeCheck(tempNode, init)) {	// ���ͼ��
						std::cerr << "[Error] type mismatch in declaration of \"" << arrName << "\"" << std::endl;
						success_flag = false;
						for (int i = init_name.size() - 1; i >= 0; --i)
							inter_code.free_temp_name(init_name[i]);
						return;
					}
					init_name.push_back(init.varname);
					// ��ʼ���б�����
					if (init_name.size() > arr_size) {
						std::cerr << "[Error] too many initializers in declaration of \"" << arrName << "\"" << std::endl;
						success_flag = false;
						return;
					}
					// �½����ű���
					idNode a;
					a.setArray(arrName, type, arr_size);
					my_symtab.insert(arrName, a);
					// �м����
					string map_arr = my_symtab.mapVarName(arrName);
					string temp1 = inter_code.gen_temp_name(),
						temp2 = inter_code.gen_temp_name(),
						temp3 = inter_code.gen_temp_name();
					inter_code.create_code_const_assign(temp1, to_string(arr_size));						// temp1 := arr_size
					inter_code.create_code_const_assign(temp2, to_string(inter_code.get_type_size(type)));	// temp2 := type_size
					inter_code.create_code_op(temp1, temp1, temp2, "*");		// temp1 := temp1 * temp2
					inter_code.create_code_memory(map_arr, temp1);				// DEC map_arr[temp1]
					inter_code.create_code_assign(temp1, map_arr);				// temp1 := map_arr
					for (int i = init_name.size() - 1; i >= 0; --i) {
						inter_code.create_code_store(temp1, init_name[i]);		// *temp1 := init
						inter_code.create_code_op(temp1, temp1, temp2, "+");	// temp1 := temp1 + temp2
						inter_code.free_temp_name(init_name[i]);
					}
					for (int i = arr_size - 1; i >= init_name.size(); --i) {
						inter_code.create_code_const_assign(temp3, "0");		// temp3 := 0
						inter_code.create_code_store(temp1, temp3);				// *temp1 := temp3
						inter_code.create_code_op(temp1, temp1, temp2, "+");	// temp1 := temp1 + temp2
					}
					inter_code.free_temp_name(temp1);
					inter_code.free_temp_name(temp2);
					inter_code.free_temp_name(temp3);
				}
			}
			// direct_declarator -> IDENTIFIER "(" parameter_type_list ")"
			else {
				std::cerr << "[Error] assignment to function" << std::endl;
				success_flag = false;
				return;
			}
		}
	}
}

// ������������
void Analyzer::analyze_function_definition(SyntaxTree *node)
{
	//cout << "analyze_function_definition" << endl;
	idNode definedfunc;
	string rettype, funcname;
	vector<varNode> paraList;
	int isVoid = 0;
	bool called = false;
	
	// function_definition -> declaration_specifiers declarator compound_statement
	SyntaxTree *declarator = node->sons.at(1);
	if (declarator->sons.back()->type != ")") {
		std::cerr << "[Error] wrong function definition" << std::endl;
		success_flag = false;
		return;
	}
	rettype = analyze_declaration_specifiers(node->sons.front());	// ��������
	funcname = declarator->sons.front()->attributes["value"];
	// declarator -> IDENTIFIER "(" parameter_list ")"
	if (declarator->sons.size() == 4) {
		paraList = analyze_parameter_list(declarator->sons.at(2));
	}
	// declarator -> IDENTIFIER "(" ")"
	else {
		varNode tmp;
		tmp.setVarNode("", "VOID");
		paraList.push_back(tmp);
	}
	definedfunc.setFunc(funcname, rettype, paraList);
	// ���ű�����
	if (my_symtab.curBlockLookup(funcname)) {
		idNode func = my_symtab.lookup(funcname);
		if (func.isFuncNode) {
			if (func.defined) {
				cerr << "[Error] redefinition of \"" << funcname << "\"" << endl;
				success_flag = false;
				return;
			}
			// �뺯��������ͻ
			else if (!isEqualIDnode(func, definedfunc)) {
				cerr << "[Error] conflicting type for \"" << funcname << "\"" << endl;
				success_flag = false;
				return;
			}
		}
		else {
			std::cerr << "[Error] redeclaration of \"" << funcname << "\"" << endl;
			success_flag = false;
			return;
		}
		called = func.called;
		my_symtab.eraseFunc(funcname);
	}
	// ���ű��½�������
	definedfunc.defined = true;
	definedfunc.called = called;
	my_symtab.insert(funcname, definedfunc);
	intoBlock();
	for (auto var : paraList) {
		idNode tmp;
		if (var.isArray) {
			tmp.setArray(var.varname, var.vartype, var.num);
		}
		else {
			tmp.setVar(var.varname, var.vartype);
		}
		if (var.vartype == "VOID") {
			if (paraList.size() > 1) {
				cerr << "[Error] VOID type in parameter list" << endl;
				success_flag = false;
			}
		}
		else {
			my_symtab.insert(var.varname, tmp);
		}
	}
	// �м����
	string map_func = my_symtab.mapFuncName(funcname), map_param;
	inter_code.create_code_func_def(map_func);				// FUNCTION map_func:
	if (paraList[0].vartype != "VOID") {
		for (auto var : paraList) {
			map_param = my_symtab.mapVarName(var.varname);
			inter_code.create_code_param(map_param);		// PARAM map_param
		}
	}
	analyze_compound_statement(node->sons.back(), true);
	exitBlock();
	return;
}

// ���������б�
vector<varNode> Analyzer::analyze_parameter_list(SyntaxTree *node)
{
	//cout << "analyze_parameter_list" << endl;
	vector<varNode> res, tmp;
	// parameter_list -> parameter_list "," parameter_declaration
	while (node->sons.size() > 1) {
		tmp.push_back(analyze_parameter_declaration(node->sons.back()));
		node = node->sons.front();
	}
	// parameter_list -> parameter_declaration
	tmp.push_back(analyze_parameter_declaration(node->sons.back()));
	// ����
	for (int i = tmp.size() - 1; i >= 0; --i)
		res.push_back(tmp.at(i));
	return res;
}

// ������������
varNode Analyzer::analyze_parameter_declaration(SyntaxTree *node)
{
	//cout << "analyze_parameter_declaration" << endl;
	string err = "[Error]", parName, parType;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");
	
	parType = analyze_declaration_specifiers(node->sons.front());
	// parameter_declaration -> declaration_specifiers IDENTIFIER
	if (node->sons.size() == 2) {
		parName = node->sons.back()->attributes["value"];
		res.setVarNode(parName, parType);
		return res;
	}
	// parameter_declaration -> declaration_specifiers IDENTIFIER "[" "]"
	else {
		parName = node->sons.at(1)->attributes["value"];
		res.setArrayNode(parName, parType, -1);
		return res;
	}
	return errNode;
}

/*************************
** ����������
*************************/

void Analyzer::analyze_statement_list(SyntaxTree *node)
{
	//cout << "analyze_statement_list" << endl;
	// statement_list -> statement_list statement
	if (node->sons.size() > 1) {
		analyze_statement_list(node->sons.front());
		analyze_statement(node->sons.back());
	}
	// statement_list -> statement
	else {
		analyze_statement(node->sons.back());
	}
}

void Analyzer::analyze_statement(SyntaxTree *node)
{
	//cout << "analyze_statement" << endl;
	// statement -> compound_statement
	if (node->sons.front()->type == "compound_statement")
		analyze_compound_statement(node->sons.front(), false);
	// statement -> expression_statement
	else if (node->sons.front()->type == "expression_statement") {
		analyze_expression_statement(node->sons.front());
	}
	// statement -> selection_statement
	else if (node->sons.front()->type == "selection_statement")
		analyze_selection_statement(node->sons.front());
	// statement -> iteration_statement
	else if (node->sons.front()->type == "iteration_statement")
		analyze_iteration_statement(node->sons.front());
	// statement -> jump_statement
	else if (node->sons.front()->type == "jump_statement")
		analyze_jump_statement(node->sons.front());
	return;
}

// �����������
void Analyzer::analyze_compound_statement(SyntaxTree *node, bool inFunc)
{
	//cout << "analyze_compound_statement" << endl;
	if (!inFunc) {
		intoBlock();
	}
	// compound_statement -> "{" statement_list "}"
	if (node->sons.at(1)->type == "statement_list") {
		SyntaxTree *statement_list = node->sons.at(1);
		analyze_statement_list(statement_list);
	}
	// compound_statement -> "{" declaration_list "}"
	else if (node->sons.at(1)->type == "declaration_list" && node->sons.size() == 3) {
		SyntaxTree *declaration_list = node->sons.at(1);
		analyze_declaration_list(declaration_list);
	}
	// compound_statement -> "{" declaration_list statement_list "}"
	else if (node->sons.at(1)->type == "declaration_list" && node->sons.size() == 4) {
		SyntaxTree *declaration_list = node->sons.at(1);
		SyntaxTree *statement_list = node->sons.at(2);
		analyze_declaration_list(declaration_list);
		analyze_statement_list(statement_list);
	}
	if (!inFunc) {
		exitBlock();
	}
	return;
}

// ����ѡ�����
void Analyzer::analyze_selection_statement(SyntaxTree *node)
{
	//cout << "analyze_selection_statement" << endl;
	varNode tempNode;
	intoBlock();
	// selection_statement -> IF "(" expression ")" statement
	if (node->sons.size() == 5) {
		// �м����
		string end_label = inter_code.gen_label();
		string temp_var = inter_code.gen_temp_name();
		varNode exp = analyze_expression(node->sons.at(2));		// ... exp
		// ���ͼ��
		tempNode.setVarNode("", "BOOL");
		if (!looseTypeCheck(tempNode, exp)) {
			std::cerr << "[Error] not bool type in declaration of \"if expression\"" << std::endl;
			success_flag = false;
		}
		// �м����
		inter_code.create_code_const_assign(temp_var, "0");		// temp_var := 0
		inter_code.create_code_cond_jump(exp.varname, temp_var, "==", end_label);	// IF exp == temp_var GOTO end_label
		analyze_statement(node->sons.back());					// ... statement
		inter_code.create_code_label(end_label);				// LABEL end_label:
	}
	// selection_statement -> IF "(" expression ")" statement ELSE statement
	else {
		// �м����
		string else_label = inter_code.gen_label(), end_label = inter_code.gen_label();
		string temp_var = inter_code.gen_temp_name();
		varNode exp = analyze_expression(node->sons.at(2));		// ... exp
		// ���ͼ��
		tempNode.setVarNode("", "BOOL");
		if (!looseTypeCheck(tempNode, exp)) {
			std::cerr << "[Error] not bool type in declaration of \"if else expression\"" << std::endl;
			success_flag = false;
		}
		// �м����
		inter_code.create_code_const_assign(temp_var, "0");		// temp_var := 0
		inter_code.create_code_cond_jump(exp.varname, temp_var, "==", else_label);	// IF exp == temp_var GOTO else_label
		analyze_statement(node->sons.at(4));					// ... statement
		inter_code.create_code_jump(end_label);					// GOTO end_label
		exitBlock();
		inter_code.create_code_label(else_label);				// LABEL else_label:
		intoBlock();
		analyze_statement(node->sons.back());					// ... statement
		inter_code.create_code_label(end_label);				// LABEL end_label:
	}
	exitBlock();
	return;
}

// ����ѭ�����
void Analyzer::analyze_iteration_statement(SyntaxTree *node)
{
	//cout << "analyze_iteration_statement" << endl;
	varNode tempNode;
	tempNode.setVarNode("", "BOOL");	// �����������ͼ��
	string start_label = inter_code.gen_label(), end_label = inter_code.gen_label();
	string temp_var = inter_code.gen_temp_name();
	intoBlock();
	// iteration_statement -> WHILE "(" expression ")" statement
	if (node->sons.front()->type == "while") {
		// �м����
		inter_code.create_code_label(start_label);				// LABEL start_label:
		varNode exp = analyze_expression(node->sons.at(2));		// ... exp
		// ������������
		if (!looseTypeCheck(tempNode, exp)) {
			std::cerr << "[Error] not bool type in declaration of \"while expression\"" << std::endl;
			success_flag = false;
		}
		// break �� continue ������ statement ��ʹ��
		++loop_count;
		break_label.push(end_label);
		continue_label.push(start_label);
		// �м����
		inter_code.create_code_const_assign(temp_var, "0");		// temp_var := 0
		inter_code.create_code_cond_jump(exp.varname, temp_var, "==", end_label);	// IF exp == temp_var GOTO end_label
		analyze_statement(node->sons.back());					// ... statement
		inter_code.create_code_jump(start_label);				// GOTO start_label
		inter_code.create_code_label(end_label);				// LABEL end_label:
		// ���� break �� continue
		--loop_count;
		break_label.pop();
		continue_label.pop();
		// �ͷſ��б�����
		inter_code.free_temp_name(exp.varname);
		inter_code.free_temp_name(temp_var);
	}
	// iteration_statement -> DO statement WHILE "(" expression ")" ";"	
	else if (node->sons.front()->type == "do") {
		string cont_label = inter_code.gen_label();
		// break �� continue ������ statement ��ʹ��
		++loop_count;
		break_label.push(end_label);
		continue_label.push(cont_label);
		// �м����
		inter_code.create_code_label(start_label);				// LABEL start_label:
		analyze_statement(node->sons.at(1));					// ... statement
		inter_code.create_code_label(cont_label);				// LABEL cont_label:
		varNode exp = analyze_expression(node->sons.at(4));		// ... exp
		// ���� break �� continue
		--loop_count;
		break_label.pop();
		continue_label.pop();
		// ������������
		if (!looseTypeCheck(tempNode, exp)) {
			std::cerr << "[Error] not bool type in declaration of \"do while expression\"" << std::endl;
			success_flag = false;
		}
		// �м����
		inter_code.create_code_const_assign(temp_var, "1");		// temp_var := 1
		inter_code.create_code_cond_jump(exp.varname, temp_var, "==", end_label);	// IF exp == temp_var GOTO start_label
		inter_code.create_code_label(end_label);				// LABEL end_label:
		// �ͷſ��б�����
		inter_code.free_temp_name(exp.varname);
		inter_code.free_temp_name(temp_var);
	}
	// iteration_statement -> FOR "(" expression_statement expression_statement ")" statement	
	else if (node->sons.front()->type == "for" && node->sons.size() == 6) {
		// �м����
		varNode init_exp = analyze_expression_statement(node->sons.at(2));		// ... init_exp
		inter_code.create_code_label(start_label);								// LABEL start_label:
		varNode cond_exp = analyze_expression_statement(node->sons.at(3));		// ... cond_exp
		// ������������
		if (!looseTypeCheck(tempNode, cond_exp)) {
			std::cerr << "[Error] not bool type in declaration of \"for expression\"" << std::endl;
			success_flag = false;
		}
		// break �� continue ������ statement ��ʹ��
		++loop_count;
		break_label.push(end_label);
		continue_label.push(start_label);
		// �м����
		if (cond_exp.vartype != "EMPTY") {
			inter_code.create_code_const_assign(temp_var, "0");	// temp_var := 0
			inter_code.create_code_cond_jump(cond_exp.varname, temp_var, "==", end_label);	// IF cond_exp == temp_var GOTO end_label
		}
		analyze_statement(node->sons.back());					// ... statement
		inter_code.create_code_jump(start_label);				// GOTO start_label
		inter_code.create_code_label(end_label);				// LABEL end_label:
		// ���� break �� continue
		--loop_count;
		break_label.pop();
		continue_label.pop();
		// �ͷſ��б�����
		inter_code.free_temp_name(init_exp.varname);
		inter_code.free_temp_name(cond_exp.varname);
		inter_code.free_temp_name(temp_var);
	}
	// iteration_statement -> FOR "(" expression_statement expression_statement expression ")" statement
	else {
		string cont_label = inter_code.gen_label();
		// �м����
		varNode init_exp = analyze_expression_statement(node->sons.at(2));		// ... init_exp
		inter_code.create_code_label(start_label);								// LABEL start_label:
		varNode cond_exp = analyze_expression_statement(node->sons.at(3));		// ... cond_exp
		// ������������
		if (!looseTypeCheck(tempNode, cond_exp)) {
			std::cerr << "[Error] not bool type in declaration of \"for expression\"" << std::endl;
			success_flag = false;
		}
		// break �� continue ������ statement ��ʹ��
		++loop_count;
		break_label.push(end_label);
		continue_label.push(cont_label);
		// �м����
		if (cond_exp.vartype != "EMPTY") {
			inter_code.create_code_const_assign(temp_var, "0");				// temp_var := 0
			inter_code.create_code_cond_jump(cond_exp.varname, temp_var, "==", end_label);	// IF cond_exp == temp_var GOTO end_label
		}
		analyze_statement(node->sons.back());								// ... statement
		inter_code.create_code_label(cont_label);							// LABEL cont_label:
		varNode iter_exp = analyze_expression_statement(node->sons.at(4));	// ... iter_exp	
		inter_code.create_code_jump(start_label);							// GOTO start_label
		inter_code.create_code_label(end_label);							// LABEL end_label:
		// ���� break �� continue
		--loop_count;
		break_label.pop();
		continue_label.pop();
		// �ͷſ��б�����
		inter_code.free_temp_name(init_exp.varname);
		inter_code.free_temp_name(cond_exp.varname);
		inter_code.free_temp_name(iter_exp.varname);
		inter_code.free_temp_name(temp_var);
	}
	exitBlock();
	return;
}

// ������ת���
void Analyzer::analyze_jump_statement(SyntaxTree *node)
{
	//cout << "analyze_jump_statement" << endl;
	// jump_statement -> RETURN expression ";"
	if (node->sons.size() == 3) {
		varNode exp = analyze_expression(node->sons.at(1));
		inter_code.create_code_return_val(exp.varname);
		inter_code.free_temp_name(exp.varname);
	}
	// jump_statement -> CONTINUE ";"
	else if (node->sons.front()->type == "continue") {
		if (loop_count > 0)
			inter_code.create_code_jump(continue_label.top());
		else {	// ��ѭ�������ʹ�� continue
			cerr << "continue outside loop" << endl;
			success_flag = false;
		}
	}
	// jump_statement -> BREAK ";"
	else if (node->sons.front()->type == "break") {
		if (loop_count > 0)
			inter_code.create_code_jump(break_label.top());
		else {	// ��ѭ������ switch �����ʹ�� break
			cerr << "break outside loop and switch" << endl;
			success_flag = false;
		}
	}
	// jump_statement -> RETURN expression ";"
	else if (node->sons.front()->type == "return") {
		inter_code.create_code_return();
	}
	return;
}

// ��������ʽ���
varNode Analyzer::analyze_expression_statement(SyntaxTree *node)
{
	//cout << "analyze_expression_statement" << endl;
	// expression_statement -> ";"
	if (node->sons.size() == 1) {
		varNode retNode;
		retNode.setVarNode("", "EMPTY");
		return retNode;
	}
	// expression_statement -> expression ";"
	else {
		return analyze_expression(node->sons.front());
	}
}

/*************************
** ����ʽ����
*************************/

varNode Analyzer::analyze_expression(SyntaxTree *node)
{
	//cout << "analyze_expression" << endl;
	varNode errNode, tempNode, resNode;
	errNode.setVarNode("", "[Error]");

	// expression -> conditional_expression
	if (node->sons.size() == 1) {
		return analyze_conditional_expression(node->sons.front());
	}
	// expression -> IDENTIFIER assignment_operator expression
	// expression -> IDENTIFIER "[" expression "]" assignment_operator expression
	else {
		// �ڷ��ű��в��ұ�ʶ��
		string id_name = node->sons.front()->attributes["value"];
		idNode front = my_symtab.lookup(id_name);
		if (front.vartype == "NOT FOUND") {	// ���ű���û�д˱�ʶ��
			cerr << "[Error] there are no identifier \"" << id_name << "\"" << endl;
			success_flag = false;
			return errNode;
		}
		else if (front.isFuncNode) {	// �ҵ����Ǻ�����
			cerr << "[Error] pointer to a function used in arithmetic" << endl;
			success_flag = false;
			return errNode;
		}
		// ���ͼ��
		varNode back = analyze_expression(node->sons.back());
		string opType = node->sons.at(node->sons.size()-2)->sons.front()->type;
		// assignment_operator -> "="
		if (opType == "=") {
			if (!looseTypeCheck(front, back)) {
				std::cerr << "[Error] type mismatch in assignment to \"" << front.varname << "\"" << std::endl;
				success_flag = false;
				return errNode;
			}
		}
		// assignment_operator -> MUL_ASSIGN | DIV_ASSIGN | ADD_ASSIGN | SUB_ASSIGN
		else if (opType == "*=" || opType == "/=" || opType == "+=" || opType == "-=") {
			if (!looseTypeCheck(front, back)) {
				std::cerr << "[Error] type mismatch in assignment to \"" << front.varname << "\"" << std::endl;
				success_flag = false;
				return errNode;
			}
		}
		// assignment_operator -> MOD_ASSIGN | LEFT_ASSIGN | RIGHT_ASSIGN | AND_ASSIGN | XOR_ASSIGN | OR_ASSIGN
		else if (opType == "%=" || opType == "<<=" || opType == ">>=" || opType == "&=" || opType == "^=" || opType == "|=") {
			tempNode.setVarNode("TO BE ASSIGNED", "EXACT INT");
			if (!looseTypeCheck(tempNode, front) || !looseTypeCheck(tempNode, back)) {
				std::cerr << "[Error] type mismatch in assignment to \"" << front.varname << "\" : not int type" << std::endl;
				success_flag = false;
				return errNode;
			}
		}
		// ��ֵ�������м����
		string map_var = my_symtab.mapVarName(id_name);
		// expression -> IDENTIFIER assignment_operator expression
		if (node->sons.size() == 3) {
			if (opType == "=") {
				inter_code.create_code_assign(map_var, back.varname);			// map_var := back
			}
			else {
				string op = opType.substr(0, opType.size() - 1);
				inter_code.create_code_op(map_var, map_var, back.varname, op);	// map_var := map_var op back
			}
			resNode.setVarNode(map_var, front.vartype);
			return resNode;
		}
		// expression -> IDENTIFIER "[" expression "]" assignment_operator expression
		else {
			varNode exp = analyze_expression(node->sons.at(2));
			tempNode.setVarNode("", "EXACT INT");	// �������ͱȽ�
			if (!front.isArray) {	// �Է����������������
				std::cerr << "[Error] \"" << id_name << "\" is not an array" << std::endl;
				success_flag = false;
				return errNode;
			}
			else if (!looseTypeCheck(tempNode, exp)) {	// �����±��޷�ת��������
				std::cerr << "[Error] array subscript is not an integer" << std::endl;
				success_flag = false;
				return errNode;
			}
			// ���ɴ���
			int type_size = inter_code.get_type_size(front.vartype);
			string map_var = my_symtab.mapVarName(id_name);
			string temp1 = inter_code.gen_temp_name(), temp2 = inter_code.gen_temp_name();
			inter_code.create_code_assign(temp2, to_string(type_size));			// temp2 := size
			inter_code.create_code_op(temp1, exp.varname, temp2, "*");			// temp1 := exp * temp2
			inter_code.create_code_op(temp2, map_var, temp1, "+");				// temp2 := map_var + temp1
			if (opType == "=") {
				inter_code.create_code_store(temp2, back.varname);				// *temp2 = back
				// �ͷſ��е���ʱ�����������÷���ֵ
				inter_code.free_temp_name(temp1);
				inter_code.free_temp_name(temp2);
				resNode.setVarNode(back.varname, front.vartype);
			}
			else {
				string op = opType.substr(0, opType.size() - 1);
				inter_code.create_code_get_content(temp1, temp2);				// temp1 := *temp2
				inter_code.create_code_op(temp1, temp1, back.varname, op);		// temp1 := temp1 op back
				inter_code.create_code_store(temp2, temp1);						// *temp2 := temp1
				// �ͷſ��е���ʱ�����������÷���ֵ
				inter_code.free_temp_name(temp2);
				resNode.setVarNode(temp1, front.vartype);
			}
			return resNode;
		}
	}
}

varNode Analyzer::analyze_conditional_expression(SyntaxTree *node) {
	//cout << "analyze_conditional_expression" << endl;
	varNode res, errNode, tempNode;
	errNode.setVarNode("", "[Error]");

	// conditional_expression -> logical_or_expression	
	if (node->sons.size() == 1) {
		return analyze_logical_or_expression(node->sons.front());
	}
	// conditional_expression -> logical_or_expression "?" expression ":" conditional_expression
	else {
		tempNode.setVarNode("", "BOOL");
		varNode condition = analyze_logical_or_expression(node->sons.front());
		if (!looseTypeCheck(tempNode, condition)) {
			std::cerr << "[Error] not bool type in ternary operator \"? : \"" << std::endl;
			success_flag = false;
			return errNode;
		}
		string label1 = inter_code.gen_label(), label2 = inter_code.gen_label();
		string temp_var = inter_code.gen_temp_name(), res_var = inter_code.gen_temp_name();
		// �м����
		inter_code.create_code_const_assign(temp_var, "0");								// temp_var := 0
		inter_code.create_code_cond_jump(condition.varname, temp_var, "==", label1);	// IF condition == temp_var GOTO label1
		varNode exp1 = analyze_expression(node->sons.at(2));							// ... code of exp1
		inter_code.create_code_assign(res_var, exp1.varname);							// res_var := exp1
		inter_code.create_code_jump(label2);											// GOTO label2
		inter_code.create_code_label(label1);											// LABEL label1:
		varNode exp2 = analyze_conditional_expression(node->sons.back());				// ... code of exp2
		inter_code.create_code_assign(res_var, exp2.varname);							// res_var := exp2
		inter_code.create_code_label(label2);											// LABEL label2:
		// ���ͼ��
		if (!looseTypeCheck(exp1, exp2) || !looseTypeCheck(exp2, exp1)) {
			std::cerr << "[Error] type mismatch in ternary operator \"? : \"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// ��ʱ�����ͷ��뷵�ؽ��
		inter_code.free_temp_name(condition.varname);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		inter_code.free_temp_name(temp_var);
		res.setVarNode(res_var, exp1.vartype);
		return res;
	}
}

varNode Analyzer::analyze_logical_or_expression(SyntaxTree *node) {
	//cout << "analyze_logical_or_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("TO BE ASSIGNED", "[Error]");

	// logical_or_expression -> logical_and_expression
	if (node->sons.size()) {
		return analyze_logical_and_expression(node->sons.front());
	}
	// logical_or_expression -> logical_or_expression OR_OP logical_and_expression
	else {
		varNode exp1 = analyze_logical_or_expression(node->sons.front()), exp2 = analyze_logical_and_expression(node->sons.back());
		varNode tempNode;
		tempNode.setVarNode("", "BOOL");
		if (!looseTypeCheck(tempNode, exp1) || !looseTypeCheck(tempNode, exp2)) {
			std::cerr << "[Error] not bool type in binary operator \"||\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "BOOL");
		return res;
	}
}

varNode Analyzer::analyze_logical_and_expression(SyntaxTree *node) {
	//cout << "analyze_logical_and_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// logical_and_expression -> inclusive_or_expression
	if (node->sons.size() == 1) {
		return analyze_inclusive_or_expression(node->sons.front());
	}
	// logical_and_expression -> logical_and_expression AND_OP inclusive_or_expression
	else {
		varNode exp1 = analyze_logical_and_expression(node->sons.front()), exp2 = analyze_inclusive_or_expression(node->sons.back());
		varNode tempNode;
		tempNode.setVarNode("", "BOOL");
		if (!looseTypeCheck(tempNode, exp1) || !looseTypeCheck(tempNode, exp2)) {
			std::cerr << "[Error] not bool type in binary operator \"&&\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "BOOL");
		return res;
	}
}

varNode Analyzer::analyze_inclusive_or_expression(SyntaxTree *node) {
	//cout << "analyze_inclusive_or_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// inclusive_or_expression -> exclusive_or_expression
	if (node->sons.size() == 1) {
		return analyze_exclusive_or_expression(node->sons.front());
	}
	// inclusive_or_expression -> inclusive_or_expression "|" exclusive_or_expression
	else {
		varNode exp1 = analyze_inclusive_or_expression(node->sons.front()), exp2 = analyze_exclusive_or_expression(node->sons.back());
		varNode tempNode;
		tempNode.setVarNode("", "EXACT INT");
		if (!looseTypeCheck(tempNode, exp1) || !looseTypeCheck(tempNode, exp2)) {
			std::cerr << "[Error] not int type in binary operator \"|\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "EXACT INT");
		return res;
	}
}

varNode Analyzer::analyze_exclusive_or_expression(SyntaxTree *node) {
	//cout << "analyze_exclusive_or_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// exclusive_or_expression -> and_expression
	if (node->sons.size() == 1) {
		return analyze_and_expression(node->sons.front());
	}
	// exclusive_or_expression -> exclusive_or_expression "^" and_expression
	else {
		varNode exp1 = analyze_exclusive_or_expression(node->sons.front()), exp2 = analyze_and_expression(node->sons.back());
		varNode temp_node;
		temp_node.setVarNode("", "EXACT INT");
		if (!looseTypeCheck(temp_node, exp1) || !looseTypeCheck(temp_node, exp2)) {
			std::cerr << "[Error] not int type in binary operator \"^\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "EXACT INT");
		return res;
	}
}

varNode Analyzer::analyze_and_expression(SyntaxTree *node) {
	//cout << "analyze_and_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// and_expression -> equality_expression
	if (node->sons.size() == 1) {
		return analyze_equality_expression(node->sons.front());
	}
	// and_expression -> and_expression "&" equality_expression
	else {
		varNode exp1 = analyze_and_expression(node->sons.front()), exp2 = analyze_equality_expression(node->sons.back());
		varNode temp_node;
		temp_node.setVarNode("", "EXACT INT");
		if (!looseTypeCheck(temp_node, exp1) || !looseTypeCheck(temp_node, exp2)) {
			std::cerr << "[Error] not int type in binary operator \"&\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "EXACT INT");
		return res;
	}
}

varNode Analyzer::analyze_equality_expression(SyntaxTree *node) {
	//cout << "analyze_equality_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// equality_expression -> relational_expression	
	if (node->sons.size() == 1) {
		return analyze_relational_expression(node->sons.front());
	}
	// equality_expression -> equality_expression EQ_OP relational_expression
	// equality_expression -> equality_expression NE_OP relational_expression
	else {
		varNode exp1 = analyze_equality_expression(node->sons.front()), exp2 = analyze_relational_expression(node->sons.back());
		if (!looseTypeCheck(exp2, exp1) || !looseTypeCheck(exp1, exp2)) {
			std::cerr << "[Error] type mismatch in binary operator \"==\" or \"!=\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "BOOL");
		return res;
	}
}

varNode Analyzer::analyze_relational_expression(SyntaxTree *node) {
	//cout << "analyze_relational_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// relational_expression -> shift_expression
	if (node->sons.size() == 1) {
		return analyze_shift_expression(node->sons.front());
	}
	// relational_expression -> relational_expression "<" shift_expression
	// relational_expression -> relational_expression ">" shift_expression 
	// relational_expression -> relational_expression LE_OP shift_expression
	// relational_expression -> relational_expression GE_OP shift_expression
	else {
		varNode exp1 = analyze_relational_expression(node->sons.front()), exp2 = analyze_shift_expression(node->sons.back());
		if (!looseTypeCheck(exp2, exp1) || !looseTypeCheck(exp1, exp2)) {	// ���ͼ��
			std::cerr << "[Error] type mismatch in binary operator \"<\" or \">\" or \"<=\" or \">=\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "BOOL");
		return res;
	}
}

varNode Analyzer::analyze_shift_expression(SyntaxTree *node) {
	//cout << "analyze_shift_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// shift_expression -> additive_expression
	if (node->sons.size() == 1) {
		return analyze_additive_expression(node->sons.front());
	}
	// shift_expression -> shift_expression LEFT_OP additive_expression
	// shift_expression -> shift_expression RIGHT_OP additive_expression
	else {
		varNode exp1 = analyze_shift_expression(node->sons.front()), exp2 = analyze_additive_expression(node->sons.back());
		varNode temp_node;
		temp_node.setVarNode("TO BE ASSIGNED", "EXACT INT");
		if (!looseTypeCheck(temp_node, exp1) || !looseTypeCheck(temp_node, exp2)) {	// ���ͼ��
			std::cerr << "[Error] not int type in binary operator \"<<\" or \">>\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, "EXACT INT");
		return res;
	}
}

varNode Analyzer::analyze_additive_expression(SyntaxTree *node) 
{
	//cout << "analyze_additive_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// additive_expression -> multiplicative_expression
	if (node->sons.size() == 1) {
		return analyze_multiplicative_expression(node->sons.front());
	}
	// additive_expression -> additive_expression "+" multiplicative_expression
	// additive_expression -> additive_expression "-" multiplicative_expression
	else {
		varNode exp1 = analyze_additive_expression(node->sons.front()), exp2 = analyze_multiplicative_expression(node->sons.back());
		if (!looseTypeCheck(exp2, exp1) || !looseTypeCheck(exp1, exp2)) {
			std::cerr << "[Error] type mismatch in binary operator \"+\" or \"-\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.setVarNode(temp_name, exp1.vartype);
		return res;
	}
}

varNode Analyzer::analyze_multiplicative_expression(SyntaxTree *node) 
{
	//cout << "analyze_multiplicative_expression" << endl;
	varNode res, errNode;
	errNode.setVarNode("", "[Error]");

	// multiplicative_expression -> cast_expression
	if (node->sons.size() == 1) {
		return analyze_cast_expression(node->sons.front());
	}
	else {
		varNode exp1 = analyze_multiplicative_expression(node->sons.front()), exp2 = analyze_cast_expression(node->sons.back());
		// multiplicative_expression -> multiplicative_expression "%" cast_expression
		if (node->sons.at(1)->type == "%") {
			varNode temp_node;
			temp_node.setVarNode("", "EXACT INT");
			if (!looseTypeCheck(temp_node, exp1) || !looseTypeCheck(temp_node, exp2)) {
				std::cerr << "[Error] not int type in binary operator \"%\"" << std::endl;
				success_flag = false;
				return errNode;
			}
			res.vartype = "EXACT INT";
		}
		// multiplicative_expression -> multiplicative_expression "*" cast_expression
		// multiplicative_expression -> multiplicative_expression "/" cast_expression
		else {
			if (!looseTypeCheck(exp2, exp1) || !looseTypeCheck(exp1, exp2)) {
				std::cerr << "[Error] type mismatch in binary operator \"*\" or \"/\"" << std::endl;
				success_flag = false;
				return errNode;
			}
			res.vartype = exp1.vartype;
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp1.varname, exp2.varname, node->sons.at(1)->type);
		inter_code.free_temp_name(exp1.varname);
		inter_code.free_temp_name(exp2.varname);
		// ���÷���ֵ
		res.varname = temp_name;
		return res;
	}
	return res;
}

varNode Analyzer::analyze_cast_expression(SyntaxTree *node)
{
	//cout << "analyze_cast_expression" << endl;
	varNode errNode;
	errNode.setVarNode("", "[Error]");

	// cast_expression -> unary_expression
	if (node->sons.front()->type == "unary_expression") {
		return analyze_unary_expression(node->sons.front());
	}
	// cast_expression -> "(" declaration_specifiers ")" cast_expression
	else {
		string cast_type = analyze_declaration_specifiers(node->sons.front());
		varNode from = analyze_cast_expression(node->sons.back()), to;
		to.setVarNode(from.varname, cast_type);
		if (!looseTypeCheck(to, from)) {	// ����ת�����
			cerr << "[Error] can't operate type cast" << endl;
			success_flag = false;
			return errNode;
		}
		inter_code.create_code_cast(from.varname, from.varname, cast_type);
		return to;
	}
}

varNode Analyzer::analyze_unary_expression(SyntaxTree *node) 
{
	//cout << "analyze_unary_expression" << endl;
	varNode res, errNode, temp_node;
	errNode.setVarNode("", "[Error]");

	// unary_expression -> postfix_expression
	if (node->sons.size() == 1) {
		return analyze_postfix_expression(node->sons.front());
	}
	// unary_expression -> INC_OP unary_expression
	// unary_expression -> DEC_OP unary_expression
	else if (node->sons.front()->type == "++" || node->sons.front()->type == "--") {
		vector<int> op_type;
		SyntaxTree *temp_tree = node;
		// ��¼ǰ�õ��������Լ������
		while (temp_tree->sons.size() != 1) {
			if (temp_tree->sons.front()->type == "++")
				op_type.push_back(1);
			else if (temp_tree->sons.front()->type == "--")
				op_type.push_back(-1);
			else {	// �����Լ������� sizeof��unary_operator ����Ƕ��
				cerr << "[Error] error in unary operator \"++\" or \"--\"" << endl;
				success_flag = false;
				return errNode;
			}
			temp_tree = temp_tree->sons.back();
		}
		temp_tree = temp_tree->sons.front();
		// ��¼���õ��������Լ������
		while (temp_tree->sons.size() != 1) {
			if (temp_tree->sons.back()->type == "++")
				op_type.push_back(1);
			else
				op_type.push_back(-1);
			temp_tree = temp_tree->sons.front();
		}
		temp_tree = temp_tree->sons.front();
		// ���ܶԷ���ֵ�����������Լ�
		if (temp_tree->sons.front()->type != "IDENTIFIER" || temp_tree->sons.back()->type == ")") {
			cerr << "[Error] non-left value in unary operator \"++\" or \"--\"" << endl;
			success_flag = false;
			return errNode;
		}
		// �ڷ��ű��в�����ֵ
		string id_name = temp_tree->sons.front()->attributes["value"];
		idNode id_node = my_symtab.lookup(id_name);
		if (id_node.vartype == "NOT FOUND") {	// ���ű���û�д˱�ʶ��
			cerr << "[Error] there are no identifier \"" << id_name << "\"" << endl;
			success_flag = false;
			return errNode;
		}
		else if (id_node.isFuncNode) {	// �ҵ����Ǻ�����
			cerr << "[Error] function pointer not support" << endl;
			success_flag = false;
			return errNode;
		}
		// �м����
		// primary_expression -> IDENTIFIER
		if (temp_tree->sons.size() == 1) {
			string map_name = my_symtab.mapVarName(id_name);
			for (int i = op_type.size() - 1; i >= 0; --i) {
				if (op_type[i] == 1)
					inter_code.create_code_op(map_name, map_name, "1", "+");
				else
					inter_code.create_code_op(map_name, map_name, "1", "-");
			}
			res.setVarNode(map_name, id_node.vartype);
			return res;

		}
		// primary_expression -> IDENTIFIER "[" expression "]"
		else {
			varNode exp = analyze_expression(node->sons.at(2));
			temp_node.setVarNode("", "EXACT INT");	// �������ͼ��
			if (!id_node.isArray) {	// �Է����������������
				std::cerr << "[Error] \"" << id_name << "\" is not an array" << std::endl;
				success_flag = false;
				return errNode;
			}
			else if (!looseTypeCheck(temp_node, exp)) {	// �����±��޷�ת��������
				std::cerr << "[Error] array subscript is not an integer" << std::endl;
				success_flag = false;
				return errNode;
			}
			// ������������ expression �ǳ�ֵ����ʽ���ҳ������鷶Χ��Ӧ�ÿ���������ǰ����
			// ���ɴ���
			int type_size = inter_code.get_type_size(id_node.vartype);
			string map_name = my_symtab.mapVarName(id_name);
			string temp1 = inter_code.gen_temp_name(), temp2 = inter_code.gen_temp_name();
			inter_code.create_code_op(temp1, exp.varname, to_string(type_size), "*");	// temp1 := exp * arr_size
			inter_code.create_code_op(temp2, map_name, temp1, "+");						// temp2 := arr + temp1
			inter_code.create_code_get_content(temp1, temp2);							// temp1 := *temp2
			for (int i = op_type.size() - 1; i >= 0; --i) {
				if (op_type[i] == 1)
					inter_code.create_code_op(temp1, temp1, "1", "+");					// temp1 := temp1 + 1
				else
					inter_code.create_code_op(temp1, temp1, "1", "-");					// temp1 := temp1 -1
			}
			inter_code.create_code_store(temp2, temp1);									// *temp2 := temp1
			// �ͷſ��е���ʱ�����������÷���ֵ
			inter_code.free_temp_name(exp.varname);
			inter_code.free_temp_name(temp2);
			res.setVarNode(temp1, id_node.vartype);
			return res;
		}
	}
	// unary_expression -> SIZEOF "(" declaration_specifiers ")"
	else if (node->sons.front()->type == "SIZEOF") {
		string type_name = analyze_declaration_specifiers(node->sons.at(2));
		int type_size = inter_code.get_type_size(type_name);
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_assign(temp_name, to_string(type_size));
		res.setVarNode(temp_name, "INT");
		return res;
	}
	// unary_expression -> unary_operator cast_expression
	else {
		varNode exp = analyze_cast_expression(node->sons.back());
		SyntaxTree *op = node->sons.front()->sons.front();
		// unary_operator -> "+"
		// unary_operator -> "-"
		if (op->type == "+" || op->type == "-") {
			temp_node.setVarNode("", "INT");
			if (!looseTypeCheck(temp_node, exp)) {
				std::cerr << "[Error] type mismatch in unary operator \"+\" or \"-\"" << std::endl;
				success_flag = false;
				return errNode;
			}
		}
		// unary_operator -> "~"
		// unary_operator -> "!"
		else {
			temp_node.setVarNode("", "EXACT INT");
			if (!looseTypeCheck(temp_node, exp)) {
				std::cerr << "[Error] type mismatch in unary operator \"~\" or \"!\"" << std::endl;
				success_flag = false;
				return errNode;
			}
		}
		// �����м����
		string temp_name = inter_code.gen_temp_name();
		inter_code.create_code_op(temp_name, exp.varname, op->type);
		inter_code.free_temp_name(exp.varname);
		res.setVarNode(temp_name, exp.vartype);
		return res;
	}
}

varNode Analyzer::analyze_postfix_expression(SyntaxTree *node) 
{
	//cout << "analyze_postfix_expression" << endl;
	varNode res, errNode, temp_node;
	errNode.setVarNode("", "[Error]");

	// postfix_expression -> primary_expression
	if (node->sons.size() == 1) {
		return analyze_primary_expression(node->sons.front());
	}
	// postfix_expression -> postfix_expression INC_OP
	// postfix_expression -> postfix_expression DEC_OP
	else {
		vector<int> op_type;	// ��¼�������Լ������
		SyntaxTree *temp_tree = node;
		while (temp_tree->sons.size() != 1) {
			if (temp_tree->sons.back()->type == "++")
				op_type.push_back(1);
			else
				op_type.push_back(-1);
			temp_tree = temp_tree->sons.front();
		}
		// ���ܶԷ���ֵ�����������Լ�
		if (temp_tree->sons.front()->type != "IDENTIFIER" || temp_tree->sons.back()->type == ")") {
			cerr << "[Error] error in unary operator \"++\" or \"--\"" << endl;
			success_flag = false;
			return errNode;
		}
		// �ڷ��ű��в�����ֵ
		string id_name = temp_tree->sons.front()->attributes["value"];
		idNode id_node = my_symtab.lookup(id_name);
		temp_node.setVarNode("", "INT");		// �������ͼ��
		if (id_node.vartype == "NOT FOUND") {	// ���ű���û�д˱�ʶ��
			cerr << "[Error] there are no identifier \"" << id_name << "\"" << endl;
			success_flag = false;
			return errNode;
		}
		else if (id_node.isFuncNode) {	// �ҵ����Ǻ�����
			cerr << "[Error] function pointer not support" << endl;
			success_flag = false;
			return errNode;
		}
		else if (!strictTypeCheck(id_node, temp_node)) {	// �������Լ������ֻ��������������
			std::cerr << "[Error] type mismatch in unary operator \"++\" or \"--\"" << std::endl;
			success_flag = false;
			return errNode;
		}
		// �м����
		// primary_expression -> IDENTIFIER
		if (temp_tree->sons.size() == 1) {
			string map_name = my_symtab.mapVarName(id_name);
			for (int i = op_type.size() - 1; i >= 0; --i) {
				if (op_type[i] == 1)
					inter_code.create_code_op(map_name, map_name, "1", "+");
				else
					inter_code.create_code_op(map_name, map_name, "1", "-");
			}
			res.setVarNode(map_name, id_node.vartype);
			return res;
		}
		// primary_expression -> IDENTIFIER "[" expression "]"
		else {
			varNode exp = analyze_expression(node->sons.at(2));
			temp_node.setVarNode("", "EXACT INT");	// �������ͼ��
			if (!id_node.isArray) {	// �Է����������������
				std::cerr << "[Error] \"" << id_name << "\" is not an array" << std::endl;
				success_flag = false;
				return errNode;
			}
			else if (!looseTypeCheck(temp_node, exp)) {	// �����±��޷�ת��������
				std::cerr << "[Error] array subscript is not an integer" << std::endl;
				success_flag = false;
				return errNode;
			}
			// ������������ expression �ǳ�ֵ����ʽ���ҳ������鷶Χ��Ӧ�ÿ���������ǰ����
			// ���ɴ���
			int type_size = inter_code.get_type_size(id_node.vartype);
			string map_name = my_symtab.mapVarName(id_name);
			string temp1 = inter_code.gen_temp_name(), temp2 = inter_code.gen_temp_name();
			inter_code.create_code_assign(temp2, to_string(type_size));					// temp2 := arr_size
			inter_code.create_code_op(temp1, exp.varname, to_string(type_size), "*");	// temp1 := exp * temp2
			inter_code.create_code_op(temp2, map_name, temp1, "+");						// temp2 := arr + temp1
			inter_code.create_code_get_content(temp1, temp2);							// temp1 := *temp2
			for (int i = op_type.size() - 1; i >= 0; --i) {
				if (op_type[i] == 1)
					inter_code.create_code_op(temp1, temp1, "1", "+");					// temp1 := temp1 + 1
				else
					inter_code.create_code_op(temp1, temp1, "1", "-");					// temp1 := temp1 -1
			}
			inter_code.create_code_store(temp2, temp1);									// *temp2 := temp1
			// �ͷſ��е���ʱ�����������÷���ֵ
			inter_code.free_temp_name(exp.varname);
			inter_code.free_temp_name(temp2);
			res.setVarNode(temp1, id_node.vartype);
			return res;
		}
	}
}

varNode Analyzer::analyze_primary_expression(SyntaxTree *node) 
{
	//cout << "analyze_primary_expression" << endl;
	varNode errNode, res;
	errNode.setVarNode("", "[Error]");	// ���ڳ��ִ���ʱ����

	if (node->sons.front()->type == "IDENTIFIER") {
		string id_name = node->sons.front()->attributes["value"];
		idNode id_node = my_symtab.lookup(id_name);
		if (id_node.vartype == "NOT FOUND") {	// ���ű���û�д˱�ʶ��
			cerr << "[Error] there are no identifier \"" << id_name << "\"" << endl;
			success_flag = false;
			return errNode;
		}
		// primary_expression -> IDENTIFIER
		if (node->sons.size() == 1) {
			if (id_node.isFuncNode) {	// �ҵ����Ǻ�����
				cerr << "[Error] function pointer not support" << endl;
				success_flag = false;
				return errNode;
			}
			string map_name = my_symtab.mapVarName(id_node.varname);
			if (id_node.isArray) {
				res.setArrayNode(map_name, id_node.vartype, id_node.num);
			}
			else {
				res.setVarNode(map_name, id_node.vartype);
			}
			return res;
		}
		// primary_expression -> IDENTIFIER "(" ")"
		else if (node->sons.size() == 3) {
			if (!id_node.isFuncNode) {	// �ҵ��Ĳ��Ǻ�����
				cerr << "[Error] identifier \"" << id_name << "\" not callable" << endl;
				success_flag = false;
				return errNode;
			}
			else if (id_node.paraList.size() != 1 || id_node.paraList.front().vartype != "VOID") {	// ��������ʱ��������
				cerr << "[Error] function \"" << id_name << "\" need more parameters" << endl;
				success_flag = false;
				return errNode;
			}
			if (!id_node.called) {	// ����û�б����ù�
				id_node.called = true;
				my_symtab.eraseFunc(id_node.funcname);
				my_symtab.insertFunc(id_node.funcname, id_node);
			}

			// ���ɴ���
			string map_name = my_symtab.mapFuncName(id_name);
			if (id_node.rettype == "VOID") {	// ��������Ϊ VOID
				inter_code.create_code_call(map_name);
				res.setVarNode("", id_node.rettype);
			}
			else {	// �������Ͳ��� VOID
				string temp_var = inter_code.gen_temp_name();
				inter_code.create_code_assign_call(temp_var, map_name);
				res.setVarNode(temp_var, id_node.rettype);
			}
			return res;
		}
		// primary_expression -> IDENTIFIER "(" argument_expression_list ")"
		else if (node->sons.back()->type == ")") {
			vector<varNode> argvs = analyze_argument_expression_list(node->sons.at(2));	// ʵ���б�
			if (!id_node.isFuncNode) {	// �ҵ��Ĳ��Ǻ�����
				cerr << "[Error] identifier \"" << id_name << "\" not callable" << endl;
				success_flag = false;
				return errNode;
			}
			else if (id_node.paraList.size() > argvs.size() && id_node.paraList.front().vartype != "VOID") {	// ��������ʱ��������
				std::cerr << "[Error] function \"" << id_name << "\" need more parameters" << std::endl;
				success_flag = false;
				return errNode;
			}
			else if (id_node.paraList.size() < argvs.size()) {	// ��������ʱ��������
				std::cerr << "[Error] function \"" << id_name << "\" need less parameters" << std::endl;
				success_flag = false;
				return errNode;
			}
			// �������ͼ�飬�Լ����ɴ���ʵ�ε��м����
			for (int i = 0; i < argvs.size(); ++i) {
				if (!looseTypeCheck(id_node.paraList.at(i), argvs.at(i))) {
					std::cerr << "[Error] parameter type mismatch in function \"" << id_name << "\"" << std::endl;
					success_flag = false;
					return errNode;
				}
				if (!id_node.called) {	// ����û�б����ù�
					id_node.called = true;
					my_symtab.eraseFunc(id_node.funcname);
					my_symtab.insertFunc(id_node.funcname, id_node);
				}
				inter_code.create_code_arg(argvs.at(i).varname);
			}
			// ���ɴ���
			string map_name = my_symtab.mapFuncName(id_name);
			if (id_node.rettype == "VOID") {	// ��������Ϊ VOID
				inter_code.create_code_call(map_name);
				res.setVarNode("", id_node.rettype);
			}
			else {	// �������Ͳ��� VOID
				string temp_var = inter_code.gen_temp_name();
				inter_code.create_code_assign_call(temp_var, map_name);
				res.setVarNode(temp_var, id_node.rettype);
			}
			// �ͷ�ʵ���е���ʱ������
			for (int i = 0; i < argvs.size(); ++i) {
				inter_code.free_temp_name(argvs.at(i).varname);
			}
			return res;
		}
		// primary_expression -> IDENTIFIER "[" expression "]"
		else {
			varNode exp = analyze_expression(node->sons.at(2)), temp_node;
			temp_node.setVarNode("", "EXACT INT");	// �������ͱȽ�
			if (id_node.isFuncNode) {	// �ҵ����Ǻ�����
				cerr << "[Error] pointer to a function used in arithmetic" << endl;
				success_flag = false;
				return errNode;
			}
			else if (!id_node.isArray) {	// �Է����������������
				std::cerr << "[Error] \"" << id_name << "\" is not an array" << std::endl;
				success_flag = false;
				return errNode;
			}
			else if (!looseTypeCheck(temp_node, exp)) {	// �����±��޷�ת��������
				std::cerr << "[Error] array subscript is not an integer" << std::endl;
				success_flag = false;
				return errNode;
			}
			// ������������ expression �ǳ�ֵ����ʽ���ҳ������鷶Χ��Ӧ�ÿ���������ǰ����
			// ���ɴ���
			int type_size = inter_code.get_type_size(id_node.vartype);
			string map_name = my_symtab.mapVarName(id_name);
			string temp1 = inter_code.gen_temp_name(), temp2 = inter_code.gen_temp_name();
			inter_code.create_code_assign(temp2, to_string(type_size));
			inter_code.create_code_op(temp1, exp.varname, temp2, "*");
			inter_code.create_code_op(temp2, map_name, temp1, "+");
			inter_code.create_code_get_content(temp1, temp2);
			// �ͷſ��е���ʱ�����������÷���ֵ
			inter_code.free_temp_name(exp.varname);
			inter_code.free_temp_name(temp2);
			res.setVarNode(temp1, id_node.vartype);
			return res;
		}
	}
	// primary_expression -> "(" expression ")"
	else if (node->sons.size() == 3) {
		return analyze_expression(node->sons.at(1));
	}
	// primary_expression -> STRING_LITERAL
	else if (node->sons.front()->type == "STRING_LITERAL") {
		string str_literal = node->sons.front()->attributes["value"];
		// ���ɴ��룺Ϊ�����ַ��������ڴ�ռ䣬�����г�ʼ��
		string array_name = inter_code.gen_temp_name();
		string temp_addr = inter_code.gen_temp_name(), temp_var = inter_code.gen_temp_name();
		inter_code.create_code_assign(temp_var, to_string(str_literal.size() + 1));	// temp_var := size
		inter_code.create_code_memory(array_name, temp_var);			// DEC array_name[temp_var]
		inter_code.create_code_assign(temp_addr, array_name);			// temp_addr := array_name			
		for (int i = 0; i < str_literal.size(); ++i) {	
			string a_char = to_string(str_literal[i]);
			inter_code.create_code_const_assign(temp_var, a_char);		// temp_var := a_char
			inter_code.create_code_store(temp_addr, temp_var);			// *temp_addr := temp_var
			inter_code.create_code_op(temp_addr, temp_addr, "1", "+");	// temp_addr := temp_addr + 1
		}
		inter_code.create_code_const_assign(temp_var, "0");				// temp_var := 0
		inter_code.create_code_store(temp_addr, temp_var);				// *temp_addr := temp_var
		inter_code.free_temp_name(temp_addr);
		inter_code.free_temp_name(temp_var);
		res.setArrayNode(array_name, "CONSTANT CHAR", str_literal.size() + 1);
		return res;
	}
	// primary_expression -> CONSTANT_CHAR
	else if (node->sons.front()->type == "CONSTANT_CHAR") {
		char a_char = (node->sons.front()->attributes["value"])[0];
		res.setVarNode(to_string(a_char), "CONSTANT CHAR");
		return res;
	}
	// primary_expression -> CONSTANT_FLOAT
	else if (node->sons.front()->type == "CONSTANT_FLOAT") {
		res.setVarNode(node->sons.front()->attributes["value"], "CONSTANT FLOAT");
		return res;
	}
	// primary_expression -> CONSTANT_HEX
	// primary_expression -> CONSTANT_DEC
	// primary_expression -> CONSTANT_OCT
	else if (node->sons.front()->type == "CONSTANT_HEX" || node->sons.front()->type == "CONSTANT_DEC" || node->sons.front()->type == "CONSTANT_OCT") {
		res.setVarNode(node->sons.front()->attributes["value"], "CONSTANT INT");
		return res;
	}
	// primary_expression -> TRUE
	// primary_expression -> FALSE
	else {
		res.setVarNode(node->sons.front()->attributes["value"], "CONSTANT BOOL");
		return res;
	}
	return res;
}

// ���������б�
std::vector<varNode> Analyzer::analyze_argument_expression_list(SyntaxTree *node)
{
	//cout << "analyze_argument_expression_list" << endl;
	std::vector<varNode> res;
	// argument_expression_list -> expression
	if (node->sons.size() == 1) {
		res.push_back(analyze_expression(node->sons.front()));
		return res;
	}
	// argument_expression_list -> argument_expression_list "," assignment_expression
	else {
		res = analyze_argument_expression_list(node->sons.front());
		res.push_back(analyze_expression(node->sons.back()));
		return res;
	}
}

bool Analyzer::strictTypeCheck(varNode to_node, varNode from_node)
{
	int narr = (int)to_node.isArray + (int)from_node.isArray, nvoid = 0;
	std::vector<std::string> to_type, from_type;
	std::stringstream to_ss(to_node.vartype), from_ss(from_node.vartype);
	std::string to_base, from_base;

	while (to_ss >> to_base) {
		to_type.push_back(to_base);
	}
	while (from_ss >> from_base) {
		from_type.push_back(from_base);
	}
	nvoid = (int)(to_base == "VOID") + (int)(from_base == "VOID");
	if (narr == 1 || nvoid == 1)
		return false;
	if (to_node.vartype == "NOT FOUND" || from_node.vartype == "NOT FOUND")
		return false;
	if (to_type.front() == "[Error]" || from_type.front() == "[Error]")
		return false;
	if (to_base == "INT" && from_base == "FLOAT")
		return false;
	if (from_base == "INT" && to_base == "FLOAT")
		return false;
	if (to_type.front() == "CONSTANT" && to_base == "INT") {
		if (from_type.front() == "CONSTANT" && from_base == "INT")
			return true;

		return false;
	}
	return true;
}

bool Analyzer::looseTypeCheck(varNode to_node, varNode from_node)
{
	int narr = (int)to_node.isArray + (int)from_node.isArray, nvoid = 0;
	std::vector<std::string> to_type, from_type;
	std::stringstream to_ss(to_node.vartype), from_ss(from_node.vartype);
	std::string to_base, from_base;

	while (to_ss >> to_base) {
		to_type.push_back(to_base);
	}
	while (from_ss >> from_base) {
		from_type.push_back(from_base);
	}
	nvoid = (int)(to_base == "VOID") + (int)(from_base == "VOID");
	if (narr == 1 || nvoid == 1)
		return false;
	if (to_node.vartype == "NOT FOUND" || from_node.vartype == "NOT FOUND")
		return false;
	if (to_type.front() == "[Error]" || from_type.front() == "[Error]")
		return false;
	if (to_base == "INT" && from_base == "FLOAT")
		return false;
	if (from_base == "INT" && to_base == "FLOAT")
		return false;
	return true;
}

void Analyzer::intoBlock()
{
	Blocks++;
	my_symtab.intoBlock();
}

void Analyzer::exitBlock()
{
	my_symtab.exitBlock();
}

void Analyzer::printSymTab()
{
	my_symtab.printSymTab();
}

void Analyzer::printComSymTab()
{
	my_symtab.printCompactSymTab();
}

void Analyzer::printInterCode()
{
	inter_code.print_code();
}