#ifndef _ANALYZE_H_
#define _ANALYZE_H_

#include "syntax_tree.h"
#include "symtab.h"
#include "inter_code.h"
#include <iostream>
#include <stack>

using namespace std;

// Semantic Analysis & Intermediate Code Generation
class Analyzer
{
public:
	Analyzer(SyntaxTree *t);
	void printSymTab();
	void printComSymTab();
	void printInterCode();
	bool success_flag;

private:
	void buildSymTab(SyntaxTree *node);

	void analyze_declaration_list(SyntaxTree *node);
	void analyze_declaration(SyntaxTree *node);
	std::string analyze_declaration_specifiers(SyntaxTree *node);
	void analyze_init_declarator_list(std::string type, SyntaxTree *node);
	void analyze_init_declarator(std::string type, SyntaxTree *node);

	void analyze_function_definition(SyntaxTree *node);
	std::vector<varNode> analyze_parameter_list(SyntaxTree *node);
	varNode analyze_parameter_declaration(SyntaxTree *node);

	void analyze_statement_list(SyntaxTree *node);
	void analyze_statement(SyntaxTree *node);
	void analyze_compound_statement(SyntaxTree *node, bool inFunc);
	varNode analyze_expression_statement(SyntaxTree *node);
	void analyze_selection_statement(SyntaxTree *node);
	void analyze_iteration_statement(SyntaxTree *node);
	void analyze_jump_statement(SyntaxTree *node);

	std::vector<varNode> analyze_argument_expression_list(SyntaxTree *node);

	// ����ʽ����
	varNode analyze_expression(SyntaxTree *node);
	varNode analyze_conditional_expression(SyntaxTree *node);
	varNode analyze_logical_or_expression(SyntaxTree *node);
	varNode analyze_logical_and_expression(SyntaxTree *node);
	varNode analyze_inclusive_or_expression(SyntaxTree *node);
	varNode analyze_exclusive_or_expression(SyntaxTree *node);
	varNode analyze_and_expression(SyntaxTree *node);
	varNode analyze_equality_expression(SyntaxTree *node);
	varNode analyze_relational_expression(SyntaxTree *node);
	varNode analyze_shift_expression(SyntaxTree *node);
	varNode analyze_additive_expression(SyntaxTree *node);
	varNode analyze_multiplicative_expression(SyntaxTree *node);
	varNode analyze_cast_expression(SyntaxTree *node);
	varNode analyze_unary_expression(SyntaxTree *node);
	varNode analyze_postfix_expression(SyntaxTree *node);
	varNode analyze_primary_expression(SyntaxTree *node);

	bool strictTypeCheck(varNode to_node, varNode from_node);
	bool looseTypeCheck(varNode to_node, varNode from_node);
	void intoBlock();
	void exitBlock();

	// �����������ʱ�ĸ�������
	stack<string> continue_label;	// continue ��ת�ı�ǩ
	stack<string> break_label;		// break ��ת�ı�ǩ
	int loop_count;					// �Ƿ����� continue ���� break ������

	SyntaxTree *root;			// �﷨�����ڵ�
	Symbol_Table my_symtab;		// ���ű�
	Inter_Code inter_code;		// �м����
	int Blocks;
};

#endif // !_ANALYZE_H_