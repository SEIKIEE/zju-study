#include "driver.h"
#include "parser.tab.h"

driver::driver()
    : trace_parsing(false), trace_scanning(false)
{
}

int driver::parse(const std::string &f)
{
    is_successful = true;
    file = f;
    location.initialize(&file);
    if (scan_begin())
    {
        yy::parser parser(*this);
        parser.set_debug_level(trace_parsing);
        int res = parser.parse();
        scan_end();
        return res;
    }
    return 1;
}
