// A Bison parser, made by GNU Bison 3.3.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Undocumented macros, especially those whose name start with YY_,
// are private implementation details.  Do not rely on them.





#include "parser.tab.h"


// Unqualified %code blocks.
#line 24 "parser.y" // lalr1.cc:435

# include <string>
# include "driver.h"
# include "syntax_tree.h"

std::string OCT2DEC(const std::string& oct);
std::string CHAR2DEC(const std::string& c);

#line 54 "parser.tab.cpp" // lalr1.cc:435


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Suppress unused-variable warnings by "using" E.
#define YYUSE(E) ((void) (E))

// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)


namespace yy {
#line 149 "parser.tab.cpp" // lalr1.cc:510

  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr;
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              else
                goto append;

            append:
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  parser::parser (driver& drv_yyarg)
    :
#if YYDEBUG
      yydebug_ (false),
      yycdebug_ (&std::cerr),
#endif
      drv (drv_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_number_type
  parser::by_state::type_get () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[state];
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 85: // primary_expression
      case 86: // postfix_expression
      case 87: // argument_expression_list
      case 88: // unary_expression
      case 89: // unary_operator
      case 90: // cast_expression
      case 91: // multiplicative_expression
      case 92: // additive_expression
      case 93: // shift_expression
      case 94: // relational_expression
      case 95: // equality_expression
      case 96: // and_expression
      case 97: // exclusive_or_expression
      case 98: // inclusive_or_expression
      case 99: // logical_and_expression
      case 100: // logical_or_expression
      case 101: // conditional_expression
      case 102: // assignment_operator
      case 103: // expression
      case 104: // declaration
      case 105: // declaration_specifiers
      case 106: // init_declarator_list
      case 107: // init_declarator
      case 108: // type_specifier
      case 109: // declarator
      case 110: // parameter_list
      case 111: // parameter_declaration
      case 112: // initializer
      case 113: // initializer_list
      case 114: // statement
      case 115: // compound_statement
      case 116: // declaration_list
      case 117: // statement_list
      case 118: // expression_statement
      case 119: // selection_statement
      case 120: // iteration_statement
      case 121: // jump_statement
      case 122: // translation_unit
      case 123: // external_declaration
      case 124: // function_definition
        value.YY_MOVE_OR_COPY< SyntaxTree* > (YY_MOVE (that.value));
        break;

      case 3: // ";"
      case 4: // "{"
      case 5: // "}"
      case 6: // ","
      case 7: // ":"
      case 8: // "="
      case 9: // "("
      case 10: // ")"
      case 11: // "["
      case 12: // "]"
      case 13: // "."
      case 14: // "&"
      case 15: // "!"
      case 16: // "~"
      case 17: // "-"
      case 18: // "+"
      case 19: // "*"
      case 20: // "/"
      case 21: // "%"
      case 22: // "<"
      case 23: // ">"
      case 24: // "^"
      case 25: // "|"
      case 26: // "?"
      case 27: // IDENTIFIER
      case 28: // CONSTANT_HEX
      case 29: // CONSTANT_DEC
      case 30: // CONSTANT_OCT
      case 31: // CONSTANT_CHAR
      case 32: // CONSTANT_FLOAT
      case 33: // STRING_LITERAL
      case 34: // SIZEOF
      case 35: // TRUE
      case 36: // FALSE
      case 37: // PTR_OP
      case 38: // INC_OP
      case 39: // DEC_OP
      case 40: // LEFT_OP
      case 41: // RIGHT_OP
      case 42: // LE_OP
      case 43: // GE_OP
      case 44: // EQ_OP
      case 45: // NE_OP
      case 46: // AND_OP
      case 47: // OR_OP
      case 48: // MUL_ASSIGN
      case 49: // DIV_ASSIGN
      case 50: // MOD_ASSIGN
      case 51: // ADD_ASSIGN
      case 52: // SUB_ASSIGN
      case 53: // LEFT_ASSIGN
      case 54: // RIGHT_ASSIGN
      case 55: // AND_ASSIGN
      case 56: // XOR_ASSIGN
      case 57: // OR_ASSIGN
      case 58: // TYPE_NAME
      case 59: // BOOL
      case 60: // CHAR
      case 61: // SHORT
      case 62: // INT
      case 63: // LONG
      case 64: // SIGNED
      case 65: // UNSIGNED
      case 66: // FLOAT
      case 67: // DOUBLE
      case 68: // CONST
      case 69: // VOLATILE
      case 70: // VOID
      case 71: // CASE
      case 72: // DEFAULT
      case 73: // IF
      case 74: // ELSE
      case 75: // SWITCH
      case 76: // WHILE
      case 77: // DO
      case 78: // FOR
      case 79: // GOTO
      case 80: // CONTINUE
      case 81: // BREAK
      case 82: // RETURN
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.type_get ())
    {
      case 85: // primary_expression
      case 86: // postfix_expression
      case 87: // argument_expression_list
      case 88: // unary_expression
      case 89: // unary_operator
      case 90: // cast_expression
      case 91: // multiplicative_expression
      case 92: // additive_expression
      case 93: // shift_expression
      case 94: // relational_expression
      case 95: // equality_expression
      case 96: // and_expression
      case 97: // exclusive_or_expression
      case 98: // inclusive_or_expression
      case 99: // logical_and_expression
      case 100: // logical_or_expression
      case 101: // conditional_expression
      case 102: // assignment_operator
      case 103: // expression
      case 104: // declaration
      case 105: // declaration_specifiers
      case 106: // init_declarator_list
      case 107: // init_declarator
      case 108: // type_specifier
      case 109: // declarator
      case 110: // parameter_list
      case 111: // parameter_declaration
      case 112: // initializer
      case 113: // initializer_list
      case 114: // statement
      case 115: // compound_statement
      case 116: // declaration_list
      case 117: // statement_list
      case 118: // expression_statement
      case 119: // selection_statement
      case 120: // iteration_statement
      case 121: // jump_statement
      case 122: // translation_unit
      case 123: // external_declaration
      case 124: // function_definition
        value.move< SyntaxTree* > (YY_MOVE (that.value));
        break;

      case 3: // ";"
      case 4: // "{"
      case 5: // "}"
      case 6: // ","
      case 7: // ":"
      case 8: // "="
      case 9: // "("
      case 10: // ")"
      case 11: // "["
      case 12: // "]"
      case 13: // "."
      case 14: // "&"
      case 15: // "!"
      case 16: // "~"
      case 17: // "-"
      case 18: // "+"
      case 19: // "*"
      case 20: // "/"
      case 21: // "%"
      case 22: // "<"
      case 23: // ">"
      case 24: // "^"
      case 25: // "|"
      case 26: // "?"
      case 27: // IDENTIFIER
      case 28: // CONSTANT_HEX
      case 29: // CONSTANT_DEC
      case 30: // CONSTANT_OCT
      case 31: // CONSTANT_CHAR
      case 32: // CONSTANT_FLOAT
      case 33: // STRING_LITERAL
      case 34: // SIZEOF
      case 35: // TRUE
      case 36: // FALSE
      case 37: // PTR_OP
      case 38: // INC_OP
      case 39: // DEC_OP
      case 40: // LEFT_OP
      case 41: // RIGHT_OP
      case 42: // LE_OP
      case 43: // GE_OP
      case 44: // EQ_OP
      case 45: // NE_OP
      case 46: // AND_OP
      case 47: // OR_OP
      case 48: // MUL_ASSIGN
      case 49: // DIV_ASSIGN
      case 50: // MOD_ASSIGN
      case 51: // ADD_ASSIGN
      case 52: // SUB_ASSIGN
      case 53: // LEFT_ASSIGN
      case 54: // RIGHT_ASSIGN
      case 55: // AND_ASSIGN
      case 56: // XOR_ASSIGN
      case 57: // OR_ASSIGN
      case 58: // TYPE_NAME
      case 59: // BOOL
      case 60: // CHAR
      case 61: // SHORT
      case 62: // INT
      case 63: // LONG
      case 64: // SIGNED
      case 65: // UNSIGNED
      case 66: // FLOAT
      case 67: // DOUBLE
      case 68: // CONST
      case 69: // VOLATILE
      case 70: // VOID
      case 71: // CASE
      case 72: // DEFAULT
      case 73: // IF
      case 74: // ELSE
      case 75: // SWITCH
      case 76: // WHILE
      case 77: // DO
      case 78: // FOR
      case 79: // GOTO
      case 80: // CONTINUE
      case 81: // BREAK
      case 82: // RETURN
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.type_get ())
    {
      case 85: // primary_expression
      case 86: // postfix_expression
      case 87: // argument_expression_list
      case 88: // unary_expression
      case 89: // unary_operator
      case 90: // cast_expression
      case 91: // multiplicative_expression
      case 92: // additive_expression
      case 93: // shift_expression
      case 94: // relational_expression
      case 95: // equality_expression
      case 96: // and_expression
      case 97: // exclusive_or_expression
      case 98: // inclusive_or_expression
      case 99: // logical_and_expression
      case 100: // logical_or_expression
      case 101: // conditional_expression
      case 102: // assignment_operator
      case 103: // expression
      case 104: // declaration
      case 105: // declaration_specifiers
      case 106: // init_declarator_list
      case 107: // init_declarator
      case 108: // type_specifier
      case 109: // declarator
      case 110: // parameter_list
      case 111: // parameter_declaration
      case 112: // initializer
      case 113: // initializer_list
      case 114: // statement
      case 115: // compound_statement
      case 116: // declaration_list
      case 117: // statement_list
      case 118: // expression_statement
      case 119: // selection_statement
      case 120: // iteration_statement
      case 121: // jump_statement
      case 122: // translation_unit
      case 123: // external_declaration
      case 124: // function_definition
        value.move< SyntaxTree* > (that.value);
        break;

      case 3: // ";"
      case 4: // "{"
      case 5: // "}"
      case 6: // ","
      case 7: // ":"
      case 8: // "="
      case 9: // "("
      case 10: // ")"
      case 11: // "["
      case 12: // "]"
      case 13: // "."
      case 14: // "&"
      case 15: // "!"
      case 16: // "~"
      case 17: // "-"
      case 18: // "+"
      case 19: // "*"
      case 20: // "/"
      case 21: // "%"
      case 22: // "<"
      case 23: // ">"
      case 24: // "^"
      case 25: // "|"
      case 26: // "?"
      case 27: // IDENTIFIER
      case 28: // CONSTANT_HEX
      case 29: // CONSTANT_DEC
      case 30: // CONSTANT_OCT
      case 31: // CONSTANT_CHAR
      case 32: // CONSTANT_FLOAT
      case 33: // STRING_LITERAL
      case 34: // SIZEOF
      case 35: // TRUE
      case 36: // FALSE
      case 37: // PTR_OP
      case 38: // INC_OP
      case 39: // DEC_OP
      case 40: // LEFT_OP
      case 41: // RIGHT_OP
      case 42: // LE_OP
      case 43: // GE_OP
      case 44: // EQ_OP
      case 45: // NE_OP
      case 46: // AND_OP
      case 47: // OR_OP
      case 48: // MUL_ASSIGN
      case 49: // DIV_ASSIGN
      case 50: // MOD_ASSIGN
      case 51: // ADD_ASSIGN
      case 52: // SUB_ASSIGN
      case 53: // LEFT_ASSIGN
      case 54: // RIGHT_ASSIGN
      case 55: // AND_ASSIGN
      case 56: // XOR_ASSIGN
      case 57: // OR_ASSIGN
      case 58: // TYPE_NAME
      case 59: // BOOL
      case 60: // CHAR
      case 61: // SHORT
      case 62: // INT
      case 63: // LONG
      case 64: // SIGNED
      case 65: // UNSIGNED
      case 66: // FLOAT
      case 67: // DOUBLE
      case 68: // CONST
      case 69: // VOLATILE
      case 70: // VOID
      case 71: // CASE
      case 72: // DEFAULT
      case 73: // IF
      case 74: // ELSE
      case 75: // SWITCH
      case 76: // WHILE
      case 77: // DO
      case 78: // FOR
      case 79: // GOTO
      case 80: // CONTINUE
      case 81: // BREAK
      case 82: // RETURN
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
#if defined __GNUC__ && ! defined __clang__ && ! defined __ICC && __GNUC__ * 100 + __GNUC_MINOR__ <= 408
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
#endif
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    switch (yytype)
    {
      case 3: // ";"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 707 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 4: // "{"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 713 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 5: // "}"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 719 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 6: // ","
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 725 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 7: // ":"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 731 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 8: // "="
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 737 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 9: // "("
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 743 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 10: // ")"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 749 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 11: // "["
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 755 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 12: // "]"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 761 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 13: // "."
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 767 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 14: // "&"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 773 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 15: // "!"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 779 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 16: // "~"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 785 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 17: // "-"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 791 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 18: // "+"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 797 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 19: // "*"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 803 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 20: // "/"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 809 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 21: // "%"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 815 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 22: // "<"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 821 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 23: // ">"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 827 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 24: // "^"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 833 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 25: // "|"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 839 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 26: // "?"
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 845 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 27: // IDENTIFIER
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 851 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 28: // CONSTANT_HEX
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 857 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 29: // CONSTANT_DEC
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 863 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 30: // CONSTANT_OCT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 869 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 31: // CONSTANT_CHAR
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 875 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 32: // CONSTANT_FLOAT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 881 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 33: // STRING_LITERAL
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 887 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 34: // SIZEOF
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 893 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 35: // TRUE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 899 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 36: // FALSE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 905 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 37: // PTR_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 911 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 38: // INC_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 917 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 39: // DEC_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 923 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 40: // LEFT_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 929 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 41: // RIGHT_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 935 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 42: // LE_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 941 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 43: // GE_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 947 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 44: // EQ_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 953 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 45: // NE_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 959 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 46: // AND_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 965 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 47: // OR_OP
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 971 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 48: // MUL_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 977 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 49: // DIV_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 983 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 50: // MOD_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 989 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 51: // ADD_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 995 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 52: // SUB_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1001 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 53: // LEFT_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1007 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 54: // RIGHT_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1013 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 55: // AND_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1019 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 56: // XOR_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1025 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 57: // OR_ASSIGN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1031 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 58: // TYPE_NAME
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1037 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 59: // BOOL
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1043 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 60: // CHAR
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1049 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 61: // SHORT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1055 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 62: // INT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1061 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 63: // LONG
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1067 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 64: // SIGNED
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1073 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 65: // UNSIGNED
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1079 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 66: // FLOAT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1085 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 67: // DOUBLE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1091 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 68: // CONST
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1097 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 69: // VOLATILE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1103 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 70: // VOID
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1109 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 71: // CASE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1115 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 72: // DEFAULT
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1121 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 73: // IF
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1127 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 74: // ELSE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1133 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 75: // SWITCH
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1139 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 76: // WHILE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1145 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 77: // DO
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1151 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 78: // FOR
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1157 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 79: // GOTO
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1163 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 80: // CONTINUE
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1169 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 81: // BREAK
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1175 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 82: // RETURN
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < std::string > (); }
#line 1181 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 85: // primary_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1187 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 86: // postfix_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1193 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 87: // argument_expression_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1199 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 88: // unary_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1205 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 89: // unary_operator
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1211 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 90: // cast_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1217 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 91: // multiplicative_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1223 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 92: // additive_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1229 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 93: // shift_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1235 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 94: // relational_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1241 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 95: // equality_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1247 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 96: // and_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1253 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 97: // exclusive_or_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1259 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 98: // inclusive_or_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1265 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 99: // logical_and_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1271 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 100: // logical_or_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1277 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 101: // conditional_expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1283 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 102: // assignment_operator
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1289 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 103: // expression
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1295 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 104: // declaration
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1301 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 105: // declaration_specifiers
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1307 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 106: // init_declarator_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1313 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 107: // init_declarator
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1319 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 108: // type_specifier
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1325 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 109: // declarator
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1331 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 110: // parameter_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1337 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 111: // parameter_declaration
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1343 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 112: // initializer
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1349 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 113: // initializer_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1355 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 114: // statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1361 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 115: // compound_statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1367 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 116: // declaration_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1373 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 117: // statement_list
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1379 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 118: // expression_statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1385 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 119: // selection_statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1391 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 120: // iteration_statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1397 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 121: // jump_statement
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1403 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 122: // translation_unit
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1409 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 123: // external_declaration
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1415 "parser.tab.cpp" // lalr1.cc:676
        break;

      case 124: // function_definition
#line 64 "parser.y" // lalr1.cc:676
        { yyoutput << yysym.value.template as < SyntaxTree* > (); }
#line 1421 "parser.tab.cpp" // lalr1.cc:676
        break;

      default:
        break;
    }
    yyo << ')';
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    // State.
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << yystack_[0].state << '\n';

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (drv));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      goto yydefault;

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", yyn, YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case 85: // primary_expression
      case 86: // postfix_expression
      case 87: // argument_expression_list
      case 88: // unary_expression
      case 89: // unary_operator
      case 90: // cast_expression
      case 91: // multiplicative_expression
      case 92: // additive_expression
      case 93: // shift_expression
      case 94: // relational_expression
      case 95: // equality_expression
      case 96: // and_expression
      case 97: // exclusive_or_expression
      case 98: // inclusive_or_expression
      case 99: // logical_and_expression
      case 100: // logical_or_expression
      case 101: // conditional_expression
      case 102: // assignment_operator
      case 103: // expression
      case 104: // declaration
      case 105: // declaration_specifiers
      case 106: // init_declarator_list
      case 107: // init_declarator
      case 108: // type_specifier
      case 109: // declarator
      case 110: // parameter_list
      case 111: // parameter_declaration
      case 112: // initializer
      case 113: // initializer_list
      case 114: // statement
      case 115: // compound_statement
      case 116: // declaration_list
      case 117: // statement_list
      case 118: // expression_statement
      case 119: // selection_statement
      case 120: // iteration_statement
      case 121: // jump_statement
      case 122: // translation_unit
      case 123: // external_declaration
      case 124: // function_definition
        yylhs.value.emplace< SyntaxTree* > ();
        break;

      case 3: // ";"
      case 4: // "{"
      case 5: // "}"
      case 6: // ","
      case 7: // ":"
      case 8: // "="
      case 9: // "("
      case 10: // ")"
      case 11: // "["
      case 12: // "]"
      case 13: // "."
      case 14: // "&"
      case 15: // "!"
      case 16: // "~"
      case 17: // "-"
      case 18: // "+"
      case 19: // "*"
      case 20: // "/"
      case 21: // "%"
      case 22: // "<"
      case 23: // ">"
      case 24: // "^"
      case 25: // "|"
      case 26: // "?"
      case 27: // IDENTIFIER
      case 28: // CONSTANT_HEX
      case 29: // CONSTANT_DEC
      case 30: // CONSTANT_OCT
      case 31: // CONSTANT_CHAR
      case 32: // CONSTANT_FLOAT
      case 33: // STRING_LITERAL
      case 34: // SIZEOF
      case 35: // TRUE
      case 36: // FALSE
      case 37: // PTR_OP
      case 38: // INC_OP
      case 39: // DEC_OP
      case 40: // LEFT_OP
      case 41: // RIGHT_OP
      case 42: // LE_OP
      case 43: // GE_OP
      case 44: // EQ_OP
      case 45: // NE_OP
      case 46: // AND_OP
      case 47: // OR_OP
      case 48: // MUL_ASSIGN
      case 49: // DIV_ASSIGN
      case 50: // MOD_ASSIGN
      case 51: // ADD_ASSIGN
      case 52: // SUB_ASSIGN
      case 53: // LEFT_ASSIGN
      case 54: // RIGHT_ASSIGN
      case 55: // AND_ASSIGN
      case 56: // XOR_ASSIGN
      case 57: // OR_ASSIGN
      case 58: // TYPE_NAME
      case 59: // BOOL
      case 60: // CHAR
      case 61: // SHORT
      case 62: // INT
      case 63: // LONG
      case 64: // SIGNED
      case 65: // UNSIGNED
      case 66: // FLOAT
      case 67: // DOUBLE
      case 68: // CONST
      case 69: // VOLATILE
      case 70: // VOID
      case 71: // CASE
      case 72: // DEFAULT
      case 73: // IF
      case 74: // ELSE
      case 75: // SWITCH
      case 76: // WHILE
      case 77: // DO
      case 78: // FOR
      case 79: // GOTO
      case 80: // CONTINUE
      case 81: // BREAK
      case 82: // RETURN
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 2:
#line 121 "parser.y" // lalr1.cc:919
    {drv.result = yystack_[0].value.as < SyntaxTree* > ();}
#line 1787 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 3:
#line 124 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[0].value.as < std::string > ()));}
#line 1794 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 4:
#line 126 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[3].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1804 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 5:
#line 131 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[2].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1813 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 6:
#line 135 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[3].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1823 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 7:
#line 140 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_HEX", std::to_string(std::stoi(yystack_[0].value.as < std::string > ()))));}
#line 1830 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 8:
#line 142 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_DEC", yystack_[0].value.as < std::string > ()));}
#line 1837 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 9:
#line 144 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_OCT", OCT2DEC(yystack_[0].value.as < std::string > ())));}
#line 1844 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 10:
#line 146 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_CHAR", yystack_[0].value.as < std::string > ()));}
#line 1851 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 11:
#line 148 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_FLOAT", std::to_string(std::stod(yystack_[0].value.as < std::string > ()))));}
#line 1858 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 12:
#line 150 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("TRUE", "1"));}
#line 1865 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 13:
#line 152 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("FALSE", "0"));}
#line 1872 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 14:
#line 154 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("STRING_LITERAL", yystack_[0].value.as < std::string > ()));}
#line 1879 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 15:
#line 156 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1888 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 16:
#line 160 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 1896 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 17:
#line 163 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("primary_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 1904 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 18:
#line 169 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("postfix_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1911 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 19:
#line 171 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("postfix_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1919 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 20:
#line 174 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("postfix_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 1927 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 21:
#line 177 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("postfix_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 1935 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 22:
#line 180 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("postfix_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 1943 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 23:
#line 186 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("argument_expression_list");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1950 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 24:
#line 188 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("argument_expression_list");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1959 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 25:
#line 192 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("argument_expression_list");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 1967 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 26:
#line 198 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_expression");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1974 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 27:
#line 200 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_expression");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1982 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 28:
#line 203 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_expression");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1990 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 29:
#line 206 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_expression");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 1998 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 30:
#line 209 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_expression");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2008 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 31:
#line 217 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_operator");
			 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2015 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 32:
#line 219 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_operator");
			 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2022 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 33:
#line 221 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_operator");
			 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2029 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 34:
#line 223 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("unary_operator");
			 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2036 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 35:
#line 228 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("cast_expression");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2043 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 36:
#line 230 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("cast_expression");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2053 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 37:
#line 238 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2060 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 38:
#line 240 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2069 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 39:
#line 244 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2078 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 40:
#line 248 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2087 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 41:
#line 252 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2095 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 42:
#line 255 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2103 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 43:
#line 258 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2111 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 44:
#line 261 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2119 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 45:
#line 264 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2127 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 46:
#line 267 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("multiplicative_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2135 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 47:
#line 273 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2142 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 48:
#line 275 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2151 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 49:
#line 279 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2160 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 50:
#line 283 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2168 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 51:
#line 286 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2176 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 52:
#line 289 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2184 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 53:
#line 292 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("additive_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2192 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 54:
#line 298 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2199 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 55:
#line 300 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2208 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 56:
#line 304 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2217 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 57:
#line 308 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2225 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 58:
#line 311 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2233 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 59:
#line 314 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2241 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 60:
#line 317 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("shift_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2249 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 61:
#line 323 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2256 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 62:
#line 325 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2265 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 63:
#line 329 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2274 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 64:
#line 333 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2283 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 65:
#line 337 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2292 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 66:
#line 341 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2300 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 67:
#line 344 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2308 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 68:
#line 347 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2316 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 69:
#line 350 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2324 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 70:
#line 353 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2332 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 71:
#line 356 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2340 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 72:
#line 359 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2348 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 73:
#line 362 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("relational_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2356 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 74:
#line 368 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2363 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 75:
#line 370 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2372 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 76:
#line 374 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2381 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 77:
#line 378 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2389 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 78:
#line 381 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2397 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 79:
#line 384 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2405 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 80:
#line 387 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("equality_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2413 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 81:
#line 393 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2420 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 82:
#line 395 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2429 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 83:
#line 399 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2437 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 84:
#line 402 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2445 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 85:
#line 408 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("exclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2452 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 86:
#line 410 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("exclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2461 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 87:
#line 414 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("exclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2469 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 88:
#line 417 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("exclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2477 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 89:
#line 423 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("inclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2484 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 90:
#line 425 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("inclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2493 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 91:
#line 429 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("inclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2501 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 92:
#line 432 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("inclusive_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2509 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 93:
#line 438 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2516 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 94:
#line 440 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2525 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 95:
#line 444 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2533 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 96:
#line 447 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_and_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2541 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 97:
#line 453 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2548 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 98:
#line 455 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2557 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 99:
#line 459 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2565 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 100:
#line 462 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("logical_or_expression");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2573 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 101:
#line 468 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("conditional_expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2580 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 102:
#line 470 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("conditional_expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[4].value.as < SyntaxTree* > ());
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2591 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 103:
#line 476 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("conditional_expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																		 drv.is_successful = false;}
#line 2599 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 104:
#line 479 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("conditional_expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																		 drv.is_successful = false;}
#line 2607 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 105:
#line 482 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("conditional_expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																		 drv.is_successful = false;}
#line 2615 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 106:
#line 488 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2622 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 107:
#line 490 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2629 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 108:
#line 492 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2636 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 109:
#line 494 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2643 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 110:
#line 496 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2650 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 111:
#line 498 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2657 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 112:
#line 500 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2664 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 113:
#line 502 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2671 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 114:
#line 504 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2678 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 115:
#line 506 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2685 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 116:
#line 508 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("assignment_operator");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2692 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 117:
#line 513 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2699 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 118:
#line 515 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[2].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2708 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 119:
#line 519 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression");
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[5].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[4].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[3].value.as < SyntaxTree* > ());
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
																		 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2720 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 120:
#line 529 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2729 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 121:
#line 533 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration");
															 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
															 drv.is_successful = false;}
#line 2737 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 122:
#line 539 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration_specifiers");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2744 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 123:
#line 541 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration_specifiers");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2752 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 124:
#line 547 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator_list");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2759 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 125:
#line 549 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator_list");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2768 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 126:
#line 553 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator_list");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
													 drv.is_successful = false;}
#line 2776 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 127:
#line 556 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator_list");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
													 drv.is_successful = false;}
#line 2784 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 128:
#line 562 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator");
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2791 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 129:
#line 564 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator");
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2800 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 130:
#line 568 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator");
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
									 drv.is_successful = false;}
#line 2808 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 131:
#line 571 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("init_declarator");
									 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
									 drv.is_successful = false;}
#line 2816 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 132:
#line 577 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("VOID", yystack_[0].value.as < std::string > ()));}
#line 2823 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 133:
#line 579 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("BOOL", yystack_[0].value.as < std::string > ()));}
#line 2830 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 134:
#line 581 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CHAR", yystack_[0].value.as < std::string > ()));}
#line 2837 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 135:
#line 583 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("SHORT", yystack_[0].value.as < std::string > ()));}
#line 2844 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 136:
#line 585 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("INT", yystack_[0].value.as < std::string > ()));}
#line 2851 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 137:
#line 587 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("LONG", yystack_[0].value.as < std::string > ()));}
#line 2858 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 138:
#line 589 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("FLOAT", yystack_[0].value.as < std::string > ()));}
#line 2865 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 139:
#line 591 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("DOUBLE", yystack_[0].value.as < std::string > ()));}
#line 2872 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 140:
#line 593 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("SIGNED", yystack_[0].value.as < std::string > ()));}
#line 2879 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 141:
#line 595 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("type_specifier");
					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("UNSIGNED", yystack_[0].value.as < std::string > ()));}
#line 2886 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 142:
#line 600 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declarator");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[0].value.as < std::string > ()));}
#line 2893 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 143:
#line 602 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declarator");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[3].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("CONSTANT_DEC", yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2903 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 144:
#line 607 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declarator");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[2].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2912 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 145:
#line 611 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declarator");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[3].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2922 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 146:
#line 616 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declarator");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[2].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2931 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 147:
#line 623 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("parameter_list");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2938 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 148:
#line 625 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("parameter_list");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2947 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 149:
#line 632 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("parameter_declaration");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[0].value.as < std::string > ()));}
#line 2955 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 150:
#line 635 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("parameter_declaration");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[3].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("IDENTIFIER", yystack_[2].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2965 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 151:
#line 643 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 2972 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 152:
#line 645 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2981 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 153:
#line 649 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 2991 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 154:
#line 654 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
											 drv.is_successful = false;}
#line 2999 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 155:
#line 660 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3006 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 156:
#line 662 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3015 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 157:
#line 666 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("initializer_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
											 drv.is_successful = false;}
#line 3023 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 158:
#line 672 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3030 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 159:
#line 674 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3037 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 160:
#line 676 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3044 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 161:
#line 678 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3051 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 162:
#line 680 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3058 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 163:
#line 685 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3066 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 164:
#line 688 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3075 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 165:
#line 692 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3084 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 166:
#line 696 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3094 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 167:
#line 701 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
													 drv.is_successful = false;}
#line 3102 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 168:
#line 704 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("compound_statement");
													 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
													 drv.is_successful = false;}
#line 3110 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 169:
#line 710 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3117 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 170:
#line 712 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("declaration_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3125 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 171:
#line 718 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3132 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 172:
#line 720 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("statement_list");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3140 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 173:
#line 726 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression_statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3147 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 174:
#line 728 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression_statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3155 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 175:
#line 731 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("expression_statement");
											 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
											 drv.is_successful = false;}
#line 3163 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 176:
#line 737 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("selection_statement");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[4].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3174 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 177:
#line 743 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("selection_statement");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[6].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[5].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[4].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3187 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 178:
#line 751 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("selection_statement");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
														 drv.is_successful = false;}
#line 3195 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 179:
#line 754 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("selection_statement");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
														 drv.is_successful = false;}
#line 3203 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 180:
#line 757 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("selection_statement");
														 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
														 drv.is_successful = false;}
#line 3211 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 181:
#line 763 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[4].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3222 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 182:
#line 769 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[6].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[5].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[4].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[3].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3235 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 183:
#line 777 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[5].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[4].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[3].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3247 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 184:
#line 784 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[6].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[5].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[4].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[3].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3260 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 185:
#line 792 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3268 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 186:
#line 795 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3276 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 187:
#line 798 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3284 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 188:
#line 801 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3292 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 189:
#line 804 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3300 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 190:
#line 807 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("iteration_statement");
																					 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																					 drv.is_successful = false;}
#line 3308 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 191:
#line 813 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("jump_statement");
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3316 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 192:
#line 816 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("jump_statement");
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3324 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 193:
#line 819 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("jump_statement");
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[1].value.as < std::string > ()));
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3332 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 194:
#line 822 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("jump_statement");
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[2].value.as < std::string > ()));
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree(yystack_[0].value.as < std::string > ()));}
#line 3341 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 195:
#line 826 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("jump_statement");
											 	 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
												 drv.is_successful = false;}
#line 3349 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 196:
#line 832 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("translation_unit");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3356 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 197:
#line 834 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("translation_unit");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3364 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 198:
#line 837 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("translation_unit");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
												 drv.is_successful = false;}
#line 3372 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 199:
#line 843 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("external_declaration");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3379 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 200:
#line 845 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("external_declaration");
												 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3386 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 201:
#line 850 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("function_definition");
																				 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[2].value.as < SyntaxTree* > ());
																				 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[1].value.as < SyntaxTree* > ());
																				 yylhs.value.as < SyntaxTree* > ()->sons.push_back(yystack_[0].value.as < SyntaxTree* > ());}
#line 3395 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 202:
#line 854 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("function_definition");
																				 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																				 drv.is_successful = false;}
#line 3403 "parser.tab.cpp" // lalr1.cc:919
    break;

  case 203:
#line 857 "parser.y" // lalr1.cc:919
    {yylhs.value.as < SyntaxTree* > () = SyntaxTree::NewTree("function_definition");
																				 yylhs.value.as < SyntaxTree* > ()->sons.push_back(SyntaxTree::NewTree("error"));
																				 drv.is_successful = false;}
#line 3411 "parser.tab.cpp" // lalr1.cc:919
    break;


#line 3415 "parser.tab.cpp" // lalr1.cc:919
            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state, yyla));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yyterror_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yyterror_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = yyn;
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type yystate, const symbol_type& yyla) const
  {
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    size_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yyla) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state
         merging (from LALR or IELR) and default reductions corrupt the
         expected token list.  However, the list is correct for
         canonical LR with one exception: it will still contain any
         token that will not be accepted due to an error action in a
         later state.
    */
    if (!yyla.empty ())
      {
        int yytoken = yyla.type_get ();
        yyarg[yycount++] = yytname_[yytoken];
        int yyn = yypact_[yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yyterror_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
      default: // Avoid compiler warnings.
        YYCASE_ (0, YY_("syntax error"));
        YYCASE_ (1, YY_("syntax error, unexpected %s"));
        YYCASE_ (2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_ (3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_ (4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_ (5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    std::string yyres;
    // Argument number.
    size_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const short parser::yypact_ninf_ = -285;

  const short parser::yytable_ninf_ = -129;

  const short
  parser::yypact_[] =
  {
       8,  -285,  -285,  -285,  -285,  -285,  -285,  -285,  -285,  -285,
    -285,  -285,    19,  -285,    20,  3007,  3007,  -285,  -285,  -285,
     110,   174,   146,  -285,   212,  -285,  -285,  -285,    22,   645,
      67,    -1,  -285,    88,  -285,   281,  1096,  -285,    23,  -285,
      34,  2974,  1357,   765,  -285,  -285,  -285,  -285,   362,  -285,
    -285,  -285,  -285,  -285,  -285,    39,  -285,  -285,  1393,  1393,
    -285,    44,  -285,  1429,  -285,   150,   103,   126,    62,   177,
      86,    82,    89,    95,   -20,  -285,  -285,  -285,  -285,   108,
      10,  -285,  -285,   136,    23,  -285,   831,  -285,  -285,   144,
     147,   527,   152,   156,   170,  1135,   181,  -285,    98,  -285,
    -285,   363,   159,  -285,  -285,  -285,  -285,  2974,  -285,  1465,
    1501,  1501,  1429,  1429,  1429,  1537,  1537,  1573,  1609,  1645,
    -285,  -285,  1681,  1681,  1537,  1537,  1717,  1717,  1753,  1789,
    1008,  -285,   218,   186,   197,  -285,  1171,  1825,  -285,  -285,
    -285,  -285,  -285,  -285,  -285,  -285,  -285,  -285,  1645,  3007,
     204,  1645,   195,  -285,  -285,  -285,  -285,  -285,  1861,  1897,
    1933,  1969,  2005,  2041,  2077,  2113,  2149,  2185,  2221,  2257,
    2293,  2329,  2365,  2401,  2437,  2473,  2509,   194,  3007,  -285,
    -285,  -285,  -285,  2545,  2581,    15,   143,  1210,  -285,  -285,
     468,  -285,   214,  -285,   110,   876,  -285,  -285,   445,   550,
    -285,  -285,   998,   177,   119,   150,   150,  -285,  -285,  -285,
     161,   126,   126,   844,    86,   799,    82,   231,   191,   103,
     103,   126,   126,   365,    62,    62,  3020,    89,  3008,    95,
     239,  -285,  1246,  -285,  1429,  2752,  -285,   141,  -285,  2940,
     233,  -285,   236,  1825,   204,  -285,   204,  -285,   204,  -285,
     119,   150,   119,   150,   191,   103,   191,   103,   161,   126,
     161,   126,   161,   126,   161,   126,   365,    62,   365,    62,
     998,   177,   844,    86,   799,    82,  3020,    89,  1049,   240,
    3008,    95,   237,  -285,  2790,   238,  2828,   242,   241,   245,
     921,  1285,  -285,  -285,  -285,  -285,  2617,  -285,  2974,  -285,
    -285,  -285,  -285,  2653,  -285,  -285,   273,  -285,   243,  2617,
    2689,  -285,   609,   691,   609,   609,  1645,  2725,   609,   966,
    1321,  -285,  2974,  -285,  1645,  -285,  -285,  2974,  -285,   185,
     714,   187,  -285,  -285,   250,  2866,   252,  -285,   609,  2904,
     609,   254,  -285,   609,   609,   609,   263,   264,   265,  -285,
     609,  -285,   609,  -285,  -285,  -285,  -285,  -285,  -285,  -285,
    -285
  };

  const unsigned char
  parser::yydefact_[] =
  {
       0,   198,   133,   134,   135,   136,   137,   140,   141,   138,
     139,   132,     0,   200,     0,   122,     2,   196,   199,     1,
     203,   142,     0,   124,     0,   123,   197,   121,     0,     0,
       0,     0,   120,     0,   202,     0,     0,   201,     0,   126,
     128,     0,     0,     0,    34,    33,    32,    31,     3,     7,
       8,     9,    10,    11,    14,     0,    12,    13,     0,     0,
      18,    26,    35,     0,    37,    47,    54,    61,    74,    81,
      85,    89,    93,    97,   101,   117,   151,   130,   146,     0,
       0,   147,   144,     0,   127,   125,     0,   173,   163,     0,
       0,     0,     0,     0,     0,     0,     0,   169,     0,   171,
     158,     0,     0,   159,   160,   161,   162,   131,   129,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      21,    22,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   155,     0,     0,     0,   106,     0,     0,   107,   108,
     109,   110,   111,   112,   113,   114,   115,   116,     0,     0,
       0,     0,     3,    27,    28,    19,    20,    29,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   149,     0,   145,
     143,   175,   168,     0,     0,     0,     0,     0,   191,   192,
       0,   193,     0,   174,     0,     0,   165,   170,     0,     0,
     164,   172,     0,    83,     0,    51,    50,    41,    42,    43,
       0,    66,    67,     0,    87,     0,    91,     0,     0,    57,
      58,    68,    69,     0,    77,    78,     0,    95,     0,    99,
       0,   152,     0,    15,     0,     0,     5,     0,    23,     0,
       0,   118,     0,     0,    44,    38,    45,    39,    46,    40,
      53,    49,    52,    48,    59,    55,    60,    56,    70,    62,
      71,    63,    72,    64,    73,    65,    79,    75,    80,    76,
      84,    82,    88,    86,    92,    90,    96,    94,     0,     0,
     100,    98,     0,   148,     0,     0,     0,     0,     0,     0,
       0,     0,   195,   194,   167,   166,     0,   154,   157,   153,
     156,    36,    17,     0,     6,    16,     4,    30,     0,     0,
       0,   150,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   105,    25,    24,     0,     4,   104,   103,   102,   178,
       0,   176,   185,   181,     0,     0,     0,   188,     0,     0,
       0,     0,   119,     0,     0,     0,     0,     0,     0,   189,
       0,   183,     0,   179,   180,   177,   186,   187,   182,   190,
     184
  };

  const short
  parser::yypgoto_[] =
  {
    -285,  -285,  -285,  -285,  -285,   175,  -285,   -62,   -67,   -77,
     -23,   -46,  -106,  -109,   -94,   -64,   -26,  -285,  -284,   -37,
     -29,   -25,   -13,  -285,    84,  -285,   256,  -285,    93,   244,
    -285,   -87,   248,  -285,   172,  -182,  -285,  -285,  -285,  -285,
     259,  -285
  };

  const short
  parser::yydefgoto_[] =
  {
      -1,    12,    60,    61,   237,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,   148,
      96,    13,    14,    22,    23,    15,    40,    80,    81,    77,
     132,    99,   100,   101,   102,   103,   104,   105,   106,    16,
      17,    18
  };

  const short
  parser::yytable_[] =
  {
      76,   157,    25,   203,   186,   291,   175,    76,   214,     1,
      97,    82,   321,   131,   133,   201,   178,    79,   181,    19,
     179,    20,    98,    38,   216,   326,   328,   176,    83,   109,
     134,    29,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,    36,   205,   206,   219,   220,    21,   149,    21,
     207,   208,   209,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,   273,   227,   271,   192,     2,     3,     4,
       5,     6,     7,     8,     9,    10,   197,    78,    11,   275,
     224,   225,   155,   156,   165,   166,   255,   257,    98,    84,
     217,   288,   211,   212,   251,   253,   245,   247,   249,   194,
     171,   221,   222,   229,   167,   168,   172,   238,   240,   320,
     277,   201,    39,    27,   173,    21,    28,    85,    29,   241,
     161,   162,   133,   267,   269,    21,     2,     3,     4,     5,
       6,     7,     8,     9,    10,   177,   242,    11,   112,   113,
     114,   174,   259,   261,   263,   265,   279,   303,   180,    32,
     281,   304,    33,   183,   285,   287,   184,   120,   121,   188,
     199,   187,    87,    35,   200,    79,   163,   164,    43,   158,
     159,   160,   301,   189,    44,    45,    46,    47,   110,   111,
     112,   113,   114,    30,   193,    31,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   233,    58,    59,   120,
     121,   122,   123,   300,   136,   282,   243,   234,   110,   111,
     112,   113,   114,    34,   308,  -128,    35,   293,  -128,   289,
      36,   169,   170,   231,   232,   329,   331,   332,   333,   120,
     121,   337,    89,   153,   154,    90,    91,    92,   296,    93,
      94,    95,   120,   121,   297,   306,   307,   310,   313,   311,
     316,   349,   315,   351,   317,   325,   353,   354,   355,   343,
     346,   345,   348,   359,   352,   360,   356,   357,   358,   324,
      24,   283,    37,   198,   323,    26,     0,     0,     0,     0,
     108,   135,    86,     0,    87,    35,    88,   334,   336,     0,
      43,   341,     0,     0,     0,   342,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,     0,    58,
      59,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       2,     3,     4,     5,     6,     7,     8,     9,    10,     0,
       0,    11,     0,     0,    89,     0,     0,    90,    91,    92,
       0,    93,    94,    95,   195,     0,    87,    35,   196,     0,
     135,   136,    43,   137,     0,     0,     0,     0,    44,    45,
      46,    47,   110,   111,   112,   113,   114,   115,   116,     0,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
       0,    58,    59,   120,   121,   122,   123,   124,   125,     0,
     138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
       0,     0,     2,     3,     4,     5,     6,     7,     8,     9,
      10,     0,     0,    11,     0,     0,    89,     0,     0,    90,
      91,    92,     0,    93,    94,    95,   199,     0,    87,    35,
     295,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,   292,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   109,    58,    59,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,     0,     0,    89,     0,
       0,    90,    91,    92,     0,    93,    94,    95,   185,     0,
      87,    35,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,   181,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   109,    58,    59,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,     0,     0,
      89,     0,     0,    90,    91,    92,     0,    93,    94,    95,
     199,     0,    87,    35,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    41,    58,    59,    42,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    89,    58,    59,    90,    91,    92,     0,    93,
      94,    95,   330,     0,    87,    35,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,   181,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   109,    58,
      59,   110,   111,   112,   113,   114,   115,   116,   117,   118,
     119,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,     0,     0,    89,     0,    41,    90,    91,    92,
       0,    93,    94,    95,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,   344,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,     0,    58,    59,     0,     0,     0,     0,     0,
       0,     0,     0,   109,     0,     0,   110,   111,   112,   113,
     114,   115,   116,   117,     2,     3,     4,     5,     6,     7,
       8,     9,    10,     0,   181,    11,   182,   120,   121,   122,
     123,   124,   125,   126,   127,   109,     0,     0,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   109,     0,
       0,   110,   111,   112,   113,   114,   115,   116,     0,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   181,
       0,   294,   120,   121,   122,   123,   124,   125,   126,   127,
     109,     0,     0,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   181,     0,     0,     0,     0,     0,
       0,   318,     0,     0,     0,   109,     0,     0,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   181,
       0,     0,     0,     0,     0,     0,   338,     0,     0,     0,
     109,     0,     0,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   230,   110,   111,   112,   113,   114,
     115,   116,   109,     0,     0,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,     0,   120,   121,   122,   123,
     124,   125,   126,   127,     0,     0,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   309,     0,     0,     0,
       0,     0,     0,   109,     0,     0,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,   107,     0,     0,
      42,     0,     0,     0,     0,    43,     0,     0,     0,     0,
       0,    44,    45,    46,    47,     0,     0,     0,     0,     0,
       0,     0,     0,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,     0,    58,    59,   190,     0,   191,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   235,    58,    59,     0,     0,     0,     0,     0,
      43,   236,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,     0,    58,
      59,   290,     0,    87,     0,     0,     0,     0,     0,    43,
       0,     0,     0,     0,     0,    44,    45,    46,    47,     0,
       0,     0,     0,     0,     0,     0,     0,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,   298,    58,    59,
       0,   299,     0,     0,     0,    43,     0,     0,     0,     0,
       0,    44,    45,    46,    47,     0,     0,     0,     0,     0,
       0,     0,     0,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,     0,    58,    59,   319,     0,    87,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   339,    58,    59,     0,     0,     0,     0,     0,
      43,   340,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   130,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   150,    58,    59,     0,     0,     0,
       0,     0,   151,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     150,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   202,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,   152,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   204,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   210,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   213,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     215,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    41,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   218,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   223,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   226,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     228,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   239,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   244,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   246,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   248,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     250,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   252,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,   152,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   254,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   256,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   258,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     260,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   262,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,   152,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   264,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   266,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   268,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
     152,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     270,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   272,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,   152,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   274,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,   152,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   276,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   278,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     280,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   284,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   286,    58,    59,     0,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,    44,    45,    46,    47,
       0,     0,     0,     0,     0,     0,     0,     0,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    41,    58,
      59,     0,     0,     0,     0,     0,    43,     0,     0,     0,
       0,     0,    44,    45,    46,    47,     0,     0,     0,     0,
       0,     0,     0,     0,   152,    49,    50,    51,    52,    53,
      54,    55,    56,    57,   322,    58,    59,     0,     0,     0,
       0,     0,    43,     0,     0,     0,     0,     0,    44,    45,
      46,    47,     0,     0,     0,     0,     0,     0,     0,     0,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
     327,    58,    59,     0,     0,     0,     0,     0,    43,     0,
       0,     0,     0,     0,    44,    45,    46,    47,     0,     0,
       0,     0,     0,     0,     0,     0,   152,    49,    50,    51,
      52,    53,    54,    55,    56,    57,   335,    58,    59,     0,
       0,     0,     0,     0,    43,     0,     0,     0,     0,     0,
      44,    45,    46,    47,     0,     0,     0,     0,     0,     0,
       0,     0,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,   302,    58,    59,     0,   109,     0,     0,   110,
     111,   112,   113,   114,   115,   116,   117,   118,   119,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     312,     0,     0,     0,   109,     0,     0,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   314,     0,
       0,     0,   109,     0,     0,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   347,     0,     0,     0,
     109,     0,     0,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   350,     0,     0,     0,   109,     0,
       0,   110,   111,   112,   113,   114,   115,   116,   117,   118,
     119,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   305,     0,   109,     0,     0,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   120,   121,
     122,   123,   124,   125,   126,   127,   128,   129,   109,     0,
       0,   110,   111,   112,   113,   114,   115,   116,   117,   118,
     119,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   120,   121,   122,   123,   124,   125,   126,   127,
     128,   129,   109,     0,     0,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   109,     0,     0,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   120,   121,   122,   123,
     124,   125,   126,   127,   128,     0,     0,     0,   120,   121,
     122,   123,   124,   125,   126,   127,     2,     3,     4,     5,
       6,     7,     8,     9,    10,     0,     0,    11
  };

  const short
  parser::yycheck_[] =
  {
      29,    63,    15,   109,    91,   187,    26,    36,   117,     1,
      35,    12,   296,    42,    43,   102,     6,    30,     3,     0,
      10,     1,    35,     1,   118,   309,   310,    47,    29,    14,
      43,     8,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,     8,   110,   111,   122,   123,    27,     9,    27,
     112,   113,   114,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,   172,   128,   171,    95,    59,    60,    61,
      62,    63,    64,    65,    66,    67,   101,    10,    70,   173,
     126,   127,    38,    39,    22,    23,   163,   164,   101,     1,
     119,    76,   115,   116,   161,   162,   158,   159,   160,     1,
      14,   124,   125,   129,    42,    43,    24,   136,   137,   291,
     174,   198,    28,     3,    25,    27,     6,    33,     8,   148,
      17,    18,   151,   169,   170,    27,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    27,   149,    70,    19,    20,
      21,    46,   165,   166,   167,   168,   175,     6,    12,     3,
     176,    10,     6,     9,   183,   184,     9,    38,    39,     3,
       1,     9,     3,     4,     5,   178,    40,    41,     9,    19,
      20,    21,   234,     3,    15,    16,    17,    18,    17,    18,
      19,    20,    21,     9,     3,    11,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    10,    38,    39,    38,
      39,    40,    41,   232,     9,    11,    11,    10,    17,    18,
      19,    20,    21,     1,   243,     3,     4,     3,     6,    76,
       8,    44,    45,     5,     6,   312,   313,   314,   315,    38,
      39,   318,    73,    58,    59,    76,    77,    78,     7,    80,
      81,    82,    38,    39,     5,    12,    10,     7,    10,    12,
       9,   338,    10,   340,     9,    12,   343,   344,   345,    74,
      10,    74,    10,   350,    10,   352,     3,     3,     3,   306,
      14,   178,    24,   101,   303,    16,    -1,    -1,    -1,    -1,
      36,     8,     1,    -1,     3,     4,     5,   316,   317,    -1,
       9,   320,    -1,    -1,    -1,   324,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    -1,    38,
      39,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    -1,
      -1,    70,    -1,    -1,    73,    -1,    -1,    76,    77,    78,
      -1,    80,    81,    82,     1,    -1,     3,     4,     5,    -1,
       8,     9,     9,    11,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    17,    18,    19,    20,    21,    22,    23,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      -1,    38,    39,    38,    39,    40,    41,    42,    43,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      -1,    -1,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    -1,    -1,    70,    -1,    -1,    73,    -1,    -1,    76,
      77,    78,    -1,    80,    81,    82,     1,    -1,     3,     4,
       5,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     3,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    14,    38,    39,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    -1,    -1,    73,    -1,
      -1,    76,    77,    78,    -1,    80,    81,    82,     1,    -1,
       3,     4,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     3,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    14,    38,    39,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    -1,    -1,
      73,    -1,    -1,    76,    77,    78,    -1,    80,    81,    82,
       1,    -1,     3,     4,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,     4,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    73,    38,    39,    76,    77,    78,    -1,    80,
      81,    82,     1,    -1,     3,     4,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    14,    38,
      39,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    -1,    -1,    73,    -1,     1,    76,    77,    78,
      -1,    80,    81,    82,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    74,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    -1,    38,    39,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    14,    -1,    -1,    17,    18,    19,    20,
      21,    22,    23,    24,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    -1,     3,    70,     5,    38,    39,    40,
      41,    42,    43,    44,    45,    14,    -1,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    14,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    -1,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,     3,
      -1,     5,    38,    39,    40,    41,    42,    43,    44,    45,
      14,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,     3,    -1,    -1,    -1,    -1,    -1,
      -1,    10,    -1,    -1,    -1,    14,    -1,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,     3,
      -1,    -1,    -1,    -1,    -1,    -1,    10,    -1,    -1,    -1,
      14,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,     6,    17,    18,    19,    20,    21,
      22,    23,    14,    -1,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    -1,    38,    39,    40,    41,
      42,    43,    44,    45,    -1,    -1,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,     7,    -1,    -1,    -1,
      -1,    -1,    -1,    14,    -1,    -1,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,     1,    -1,    -1,
       4,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,
      -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    -1,    38,    39,     1,    -1,     3,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    10,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    -1,    38,
      39,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,     9,
      -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,     1,    38,    39,
      -1,     5,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,
      -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    -1,    38,    39,     1,    -1,     3,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    10,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     1,    38,    39,    -1,    -1,    -1,    -1,    -1,
       9,    -1,    -1,    -1,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     1,    38,
      39,    -1,    -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     1,    38,    39,    -1,    -1,    -1,
      -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
       1,    38,    39,    -1,    -1,    -1,    -1,    -1,     9,    -1,
      -1,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     1,    38,    39,    -1,
      -1,    -1,    -1,    -1,     9,    -1,    -1,    -1,    -1,    -1,
      15,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    10,    38,    39,    -1,    14,    -1,    -1,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      10,    -1,    -1,    -1,    14,    -1,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    10,    -1,
      -1,    -1,    14,    -1,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    10,    -1,    -1,    -1,
      14,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    10,    -1,    -1,    -1,    14,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    12,    -1,    14,    -1,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    14,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    14,    -1,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    14,    -1,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    -1,    -1,    -1,    38,    39,
      40,    41,    42,    43,    44,    45,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    -1,    -1,    70
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,     1,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    70,    84,   104,   105,   108,   122,   123,   124,     0,
       1,    27,   106,   107,   109,   105,   123,     3,     6,     8,
       9,    11,     3,     6,     1,     4,     8,   115,     1,   107,
     109,     1,     4,     9,    15,    16,    17,    18,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    38,    39,
      85,    86,    88,    89,    90,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   103,   112,    10,   105,
     110,   111,    12,    29,     1,   107,     1,     3,     5,    73,
      76,    77,    78,    80,    81,    82,   103,   104,   105,   114,
     115,   116,   117,   118,   119,   120,   121,     1,   112,    14,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
       1,   103,   113,   103,   105,     8,     9,    11,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,   102,     9,
       1,     9,    27,    88,    88,    38,    39,    90,    19,    20,
      21,    17,    18,    40,    41,    22,    23,    42,    43,    44,
      45,    14,    24,    25,    46,    26,    47,    27,     6,    10,
      12,     3,     5,     9,     9,     1,   114,     9,     3,     3,
       1,     3,   103,     3,     1,     1,     5,   104,   117,     1,
       5,   114,     1,    95,     1,    91,    91,    90,    90,    90,
       1,    93,    93,     1,    96,     1,    97,   103,     1,    92,
      92,    93,    93,     1,    94,    94,     1,    98,     1,    99,
       6,     5,     6,    10,    10,     1,    10,    87,   103,     1,
     103,   103,   105,    11,     1,    90,     1,    90,     1,    90,
       1,    91,     1,    91,     1,    92,     1,    92,     1,    93,
       1,    93,     1,    93,     1,    93,     1,    94,     1,    94,
       1,    95,     1,    96,     1,    97,     1,    98,     1,   103,
       1,    99,    11,   111,     1,   103,     1,   103,    76,    76,
       1,   118,     3,     3,     5,     5,     7,     5,     1,     5,
     103,    90,    10,     6,    10,    12,    12,    10,   103,     7,
       7,    12,    10,    10,    10,    10,     9,     9,    10,     1,
     118,   101,     1,   103,   102,    12,   101,     1,   101,   114,
       1,   114,   114,   114,   103,     1,   103,   114,    10,     1,
      10,   103,   103,    74,    74,    74,    10,    10,    10,   114,
      10,   114,    10,   114,   114,   114,     3,     3,     3,   114,
     114
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    83,    84,    85,    85,    85,    85,    85,    85,    85,
      85,    85,    85,    85,    85,    85,    85,    85,    86,    86,
      86,    86,    86,    87,    87,    87,    88,    88,    88,    88,
      88,    89,    89,    89,    89,    90,    90,    91,    91,    91,
      91,    91,    91,    91,    91,    91,    91,    92,    92,    92,
      92,    92,    92,    92,    93,    93,    93,    93,    93,    93,
      93,    94,    94,    94,    94,    94,    94,    94,    94,    94,
      94,    94,    94,    94,    95,    95,    95,    95,    95,    95,
      95,    96,    96,    96,    96,    97,    97,    97,    97,    98,
      98,    98,    98,    99,    99,    99,    99,   100,   100,   100,
     100,   101,   101,   101,   101,   101,   102,   102,   102,   102,
     102,   102,   102,   102,   102,   102,   102,   103,   103,   103,
     104,   104,   105,   105,   106,   106,   106,   106,   107,   107,
     107,   107,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   108,   109,   109,   109,   109,   109,   110,   110,   111,
     111,   112,   112,   112,   112,   113,   113,   113,   114,   114,
     114,   114,   114,   115,   115,   115,   115,   115,   115,   116,
     116,   117,   117,   118,   118,   118,   119,   119,   119,   119,
     119,   120,   120,   120,   120,   120,   120,   120,   120,   120,
     120,   121,   121,   121,   121,   121,   122,   122,   122,   123,
     123,   124,   124,   124
  };

  const unsigned char
  parser::yyr2_[] =
  {
       0,     2,     1,     1,     4,     3,     4,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     4,     4,     1,     2,
       2,     2,     2,     1,     3,     3,     1,     2,     2,     2,
       4,     1,     1,     1,     1,     1,     4,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     1,     3,     3,
       3,     3,     3,     3,     1,     3,     3,     3,     3,     3,
       3,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     1,     3,     3,     3,     3,     3,
       3,     1,     3,     3,     3,     1,     3,     3,     3,     1,
       3,     3,     3,     1,     3,     3,     3,     1,     3,     3,
       3,     1,     5,     5,     5,     5,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     6,
       3,     3,     1,     2,     1,     3,     3,     3,     1,     3,
       3,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     3,     4,     3,     1,     3,     2,
       4,     1,     3,     4,     4,     1,     3,     3,     1,     1,
       1,     1,     1,     2,     3,     3,     4,     4,     3,     1,
       2,     1,     2,     1,     2,     2,     5,     7,     5,     7,
       7,     5,     7,     6,     7,     5,     7,     7,     5,     6,
       7,     2,     2,     2,     3,     3,     1,     2,     1,     1,
       1,     3,     3,     2
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"end of file\"", "error", "$undefined", "\";\"", "\"{\"", "\"}\"",
  "\",\"", "\":\"", "\"=\"", "\"(\"", "\")\"", "\"[\"", "\"]\"", "\".\"",
  "\"&\"", "\"!\"", "\"~\"", "\"-\"", "\"+\"", "\"*\"", "\"/\"", "\"%\"",
  "\"<\"", "\">\"", "\"^\"", "\"|\"", "\"?\"", "IDENTIFIER",
  "CONSTANT_HEX", "CONSTANT_DEC", "CONSTANT_OCT", "CONSTANT_CHAR",
  "CONSTANT_FLOAT", "STRING_LITERAL", "SIZEOF", "TRUE", "FALSE", "PTR_OP",
  "INC_OP", "DEC_OP", "LEFT_OP", "RIGHT_OP", "LE_OP", "GE_OP", "EQ_OP",
  "NE_OP", "AND_OP", "OR_OP", "MUL_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN",
  "ADD_ASSIGN", "SUB_ASSIGN", "LEFT_ASSIGN", "RIGHT_ASSIGN", "AND_ASSIGN",
  "XOR_ASSIGN", "OR_ASSIGN", "TYPE_NAME", "BOOL", "CHAR", "SHORT", "INT",
  "LONG", "SIGNED", "UNSIGNED", "FLOAT", "DOUBLE", "CONST", "VOLATILE",
  "VOID", "CASE", "DEFAULT", "IF", "ELSE", "SWITCH", "WHILE", "DO", "FOR",
  "GOTO", "CONTINUE", "BREAK", "RETURN", "$accept", "entry",
  "primary_expression", "postfix_expression", "argument_expression_list",
  "unary_expression", "unary_operator", "cast_expression",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "and_expression",
  "exclusive_or_expression", "inclusive_or_expression",
  "logical_and_expression", "logical_or_expression",
  "conditional_expression", "assignment_operator", "expression",
  "declaration", "declaration_specifiers", "init_declarator_list",
  "init_declarator", "type_specifier", "declarator", "parameter_list",
  "parameter_declaration", "initializer", "initializer_list", "statement",
  "compound_statement", "declaration_list", "statement_list",
  "expression_statement", "selection_statement", "iteration_statement",
  "jump_statement", "translation_unit", "external_declaration",
  "function_definition", YY_NULLPTR
  };

#if YYDEBUG
  const unsigned short
  parser::yyrline_[] =
  {
       0,   121,   121,   124,   126,   131,   135,   140,   142,   144,
     146,   148,   150,   152,   154,   156,   160,   163,   169,   171,
     174,   177,   180,   186,   188,   192,   198,   200,   203,   206,
     209,   217,   219,   221,   223,   228,   230,   238,   240,   244,
     248,   252,   255,   258,   261,   264,   267,   273,   275,   279,
     283,   286,   289,   292,   298,   300,   304,   308,   311,   314,
     317,   323,   325,   329,   333,   337,   341,   344,   347,   350,
     353,   356,   359,   362,   368,   370,   374,   378,   381,   384,
     387,   393,   395,   399,   402,   408,   410,   414,   417,   423,
     425,   429,   432,   438,   440,   444,   447,   453,   455,   459,
     462,   468,   470,   476,   479,   482,   488,   490,   492,   494,
     496,   498,   500,   502,   504,   506,   508,   513,   515,   519,
     529,   533,   539,   541,   547,   549,   553,   556,   562,   564,
     568,   571,   577,   579,   581,   583,   585,   587,   589,   591,
     593,   595,   600,   602,   607,   611,   616,   623,   625,   632,
     635,   643,   645,   649,   654,   660,   662,   666,   672,   674,
     676,   678,   680,   685,   688,   692,   696,   701,   704,   710,
     712,   718,   720,   726,   728,   731,   737,   743,   751,   754,
     757,   763,   769,   777,   784,   792,   795,   798,   801,   804,
     807,   813,   816,   819,   822,   826,   832,   834,   837,   843,
     845,   850,   854,   857
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << i->state;
    *yycdebug_ << '\n';
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    unsigned yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG



} // yy
#line 4608 "parser.tab.cpp" // lalr1.cc:1242
#line 862 "parser.y" // lalr1.cc:1243


void yy::parser::error (const location_type& l, const std::string& m)
{
	std::cerr << l << ": " << m << '\n';
}

std::string OCT2DEC(const std::string& oct)
{
	int tmp = 0;
	int len = oct.size();
	for (int i = 0; i < len; i++)
	{
		tmp += (oct[len - i - 1] - '0') * (1 << (i * 3));
	}
	return std::to_string(tmp);
}

std::string CHAR2DEC(const std::string& c)
{
	int index = c.find('\'');
	return std::to_string(int(c[index+1]));
}
