#include "symtab.h"

// ��ʼ�����������
void varNode::setArrayNode(std::string arrName, std::string arrType, int arrNum)
{
	isArray = true;
	varname = arrName;
	vartype = arrType;
	num = arrNum;
	return;
}

// ��ʼ�������������
void varNode::setVarNode(std::string varName, std::string varType)
{
	varname = varName;
	vartype = varType;
	isArray = false;
	return;
}

// ����������ű�������
std::string varNode::varInfo()
{
	std::string res;
	if (isArray) {
		res = "Array name:\t";
		if (varname != "TO BE ASSIGNED") {
			res += varname + "\t";
		}
		res += "Array of\t" + vartype + "\tsize:\t" + std::to_string(num);
	}
	else {
		res = "Variable name:\t";
		if (varname != "TO BE ASSIGNED") {
			res += varname + "\t";
		}
		res += "type:\t" + vartype;
	}
	return res;
}

// �ж��������ű����Ƿ�һ��
bool varNode::operator ==(const varNode &v)
{
	bool nameequal = varname == v.varname;
	if (varname == "TO BE ASSIGNED" || v.varname == "TO BE ASSIGNED") {
		nameequal = true;
	}
	return nameequal && vartype == v.vartype && isArray == v.isArray && num == v.num;
}

// ��ʼ��������
void funcNode::setFuncNode(std::string funcName, std::string funcRetType, std::vector<varNode> funcParaList)
{
	funcname = funcName;
	rettype = funcRetType;
	paraList = funcParaList;
	defined = false;
	called = false;
	return;
}

// ����������ű�������
std::string funcNode::funcInfo()
{
	std::string res = "";
	int i = 1;

	res = "Function name:\t" + funcname + "\treturn type\t" + rettype + "\tparameter list:\t";
	if (paraList.size() == 1 && paraList.front().vartype == "VOID") {
		return res + "\n\tVOID";
	}
	for (auto var : paraList) {
		res += "\n  (" + std::to_string(i++) + ")\t" + var.varInfo();
	}
	return res;
}

void idNode::setFunc(std::string funcName, std::string funcRetType, std::vector<varNode> funcParaList)
{
	isFuncNode = true;
	setFuncNode(funcName, funcRetType, funcParaList);
	return;
}

void idNode::setArray(std::string arrName, std::string arrType, int arrNum)
{
	isFuncNode = false;
	setArrayNode(arrName, arrType, arrNum);
	return;
}

void idNode::setVar(std::string varName, std::string varType)
{
	isFuncNode = false;
	setVarNode(varName, varType);
	return;
}

bool isEqualIDnode(idNode a, idNode b)
{
	bool res = a.isFuncNode == b.isFuncNode && a.defined == b.defined && a.funcname == b.funcname && a.rettype == b.rettype &&
		a.vartype == b.vartype && a.num == b.num && a.isArray == b.isArray;
	bool nameequal = a.varname == b.varname;
	if (a.varname == "TO BE ASSIGNED" || b.varname == "TO BE ASSIGNED") {
		nameequal = true;
	}
	res &= nameequal;
	if (a.paraList.size() != b.paraList.size()) {
		return false;
	}
	for (int i = 0; i < a.paraList.size(); ++i) {
		if (!(a.paraList.at(i) == b.paraList.at(i))) {
			return false;
		}
	}
	return res;
}

std::string idNode::info()
{
	std::string res = "";
	if (isFuncNode) {
		res = funcInfo();
	}
	else {
		res = varInfo();
	}
	return res;
}

// ���ű���ʼ��
Symbol_Table::Symbol_Table()
{
	std::unordered_map<std::string, idNode> tmp;
	SymTabs.push_back(tmp);
	isExist.push_back(true);
	curSymTab = 0;
}

// ���ű�������
void Symbol_Table::insert(std::string name, idNode node)
{
	SymTabs.at(curSymTab).insert(std::pair<std::string, idNode>(name, node));
	return;
}

// ���ű����뺯����
void Symbol_Table::insertFunc(std::string name, idNode node)
{
	SymTabs.at(0).insert(std::pair<std::string, idNode>(name, node));
	return;
}

// ��������Ч�� scope �в�����
// �����ҵ��� idNode
idNode Symbol_Table::lookup(std::string name)
{
	idNode res;
	res.vartype = "NOT FOUND";
	for (int i = SymTabs.size() - 1; i >= 0; --i) {
		if (isExist.at(i)) {
			std::unordered_map<std::string, idNode>::const_iterator got = SymTabs.at(i).find(name);
			if (got != SymTabs.at(i).end()) {
				return got->second;
			}
		}
	}
	return res;
}

// �ڵ�ǰ scope �в�����
bool Symbol_Table::curBlockLookup(std::string name)
{
	std::unordered_map<std::string, idNode>::const_iterator got = SymTabs.at(curSymTab).find(name);
	if (got != SymTabs.at(curSymTab).end()) {
		return true;
	}
	else {
		return false;
	}
}

// ɾ����
void Symbol_Table::erase(std::string name)
{
	SymTabs.at(curSymTab).erase(name);
	return;
}

// ɾ��������
void Symbol_Table::eraseFunc(std::string funcname)
{
	SymTabs.at(0).erase(funcname);
	return;
}

// �½� scope
void Symbol_Table::intoBlock()
{
	std::unordered_map<std::string, idNode> tmp;
	SymTabs.push_back(tmp);
	isExist.push_back(true);
	curSymTab = SymTabs.size() - 1;
	return;
}

// �˳� scope
void Symbol_Table::exitBlock()
{
	isExist.at(curSymTab) = false;
	for (int i = SymTabs.size() - 2; i >= 0; --i) {
		if (isExist.at(i)) {
			curSymTab = i;
			return;
		}
	}
	return;
}

// ���� scope ����
int Symbol_Table::nBlocks()
{
	return SymTabs.size();
}

// ��ӡ���ű�
void Symbol_Table::printSymTab()
{
	for (int i = 0; i < SymTabs.size(); ++i) {
		std::cout << "block " << i + 1 << std::endl;
		for (auto s : SymTabs.at(i)) {
			std::cout << s.second.info() << std::endl;
		}
		if (SymTabs.at(i).size() == 0) {
			std::cout << "empty block" << std::endl;
		}
		std::cout << std::endl;
	}
	return;
}

// ��ӡ���ű�
void Symbol_Table::printCompactSymTab()
{
	int n = 0;
	for (int i = 0; i < SymTabs.size(); ++i) {
		if (SymTabs.at(i).size() != 0) {
			std::cout << "block " << ++n << std::endl;
			for (auto s : SymTabs.at(i)) {
				std::cout << s.second.info() << std::endl;
			}
			std::cout << std::endl;
		}
	}
	return;
}

// ��ӡ���ű���ǰ scope
void Symbol_Table::printNowSymTab()
{
	for (auto s : SymTabs.at(curSymTab)) {
		std::cout << s.second.info() << std::endl;
	}
	std::cout << std::endl;
	return;
}

int Symbol_Table::findVar(string varName)
{
	// �ڳ���ȫ�ֵ� scope �в���
	for (int i = SymTabs.size() - 1; i >= 1; --i) {
		if (isExist.at(i)) {
			auto got = SymTabs.at(i).find(varName);
			if (got != SymTabs.at(i).end()) {
				return i;
			}
		}
	}
	// ��ȫ�� scope �в��ң�ע���ų������ڵ�
	auto got = SymTabs.at(0).find(varName);
	if (got != SymTabs.at(0).end() && !(got->second.isFuncNode)) {
		return 0;
	}
	// δ�ҵ�
	return -1;
}

string Symbol_Table::mapVarName(string varName)
{
	int i = findVar(varName);
	if (i == -1) {
		return "ILLIGAL";
	}
	else {
		return "V" + to_string(i) + "_" + varName;
	}
}

bool Symbol_Table::findFunc(string funcName)
{
	// ��ȫ�� scope �в���
	auto got = SymTabs.at(0).find(funcName);
	if (got != SymTabs.at(0).end() && got->second.isFuncNode) {
		return true;
	}
	// δ�ҵ�
	return false;
}

string Symbol_Table::mapFuncName(string funcName)
{
	bool flag = findFunc(funcName);
	if (!flag) {
		return "ILLIGAL";
	}
	else {
		return "F_" + funcName;
	}
}

// ����Ƿ���δ����ĺ���������
bool Symbol_Table::callUndefinedFunc()
{
	bool res = true;
	for (int i = 0; i < SymTabs.size(); ++i) {
		for (auto s : SymTabs.at(i)) {
			if (s.second.called && !s.second.defined) {
				res = false;
				std::cerr << "[Error] function \"" << s.second.funcname << "\" without being defined" << std::endl;
			}
		}
	}
	return res;
}