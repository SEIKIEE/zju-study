#include "syntax_tree.h"
#include <iostream>
#include <algorithm>

using namespace std;

SyntaxTree::SyntaxTree(const std::string& type) : type(type)
{
}

bool SyntaxTree::is_leaf()
{
    return sons.empty();
}

SyntaxTree* SyntaxTree::NewTree(std::string type, std::string value)
{
    SyntaxTree* ptr = new SyntaxTree(type);
    if (value != "")
        ptr->attributes["value"] = value;
    return ptr;
}

void SyntaxTree::FreeAll(SyntaxTree * root)
{
    for (int i = 0; i < root->sons.size(); i++)
    {
        FreeAll(root->sons[i]);
        delete root->sons[i];
    }
}

void SyntaxTree::Print(SyntaxTree * root, bool dense, std::vector<int>* bitmap)
{
    static const char* tables[] = { "    ", " ��  ", " ���� ", " ���� " };
    if (bitmap == nullptr)
    {
        bitmap = new vector<int>();
    }
    else
    {
        if (!dense)
        {
            int depth = bitmap->size();
            for (int i = 0; i < depth; i++)
            {
                int index = bitmap->at(i);
                index = min(1, index);
                cout << tables[index];
            }
            cout << '\n';
        }      
    }
    int depth = bitmap->size();
    for (int i = 0; i < depth; i++)
    {
        int index = bitmap->at(i);
        if (i != depth - 1)
            index = min(1, index);
        cout << tables[index];
    }
    if (depth > 0 && bitmap->back() == 3)
    {
        bitmap->at(depth - 1) = 0;
    }
    if (('a' <= root->type[0] && root->type[0] <= 'z') || ('A' <= root->type[0] && root->type[0] <= 'Z'))
    {
        cout << root->type;
    }
    else
    {
        cout << '\"' << root->type << '\"';
    }
    if (root->is_leaf() && root->attributes.find("value") != root->attributes.end())
    {
        cout << ": " << root->attributes["value"];
    }
    cout << '\n';
    int son_count = root->sons.size();
    for (int i = 0; i < son_count; i++)
    {
        if (i == son_count - 1)
        {
            bitmap->push_back(3);
        }
        else
        {
            bitmap->push_back(2);
        }
        SyntaxTree::Print(root->sons[i], dense, bitmap);
        bitmap->pop_back();
    }
    if (depth = 0)
    {
        delete bitmap;
    }
}
