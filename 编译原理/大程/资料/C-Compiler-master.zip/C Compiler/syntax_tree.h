#pragma once
#include <string>
#include <vector>
#include <map>
class SyntaxTree;
class SyntaxTree
{
public:
    SyntaxTree(const SyntaxTree&) = delete;
    void operator=(const SyntaxTree&) = delete;

    std::string type;
    std::vector<SyntaxTree*> sons;
    std::map<std::string, std::string> attributes;
    bool is_leaf();

    static SyntaxTree* NewTree(std::string type, std::string value = "");
    static void FreeAll(SyntaxTree * root);
    static void Print(SyntaxTree* root, bool dense = false, std::vector<int>* bitmap = nullptr);

private:
    SyntaxTree(const std::string& type);
};

