int main()
{
	while(1);
	(1+1)
	if(1);
}