int v = 10;
float f(float k) {
    float res = 1.1;
    while(v >= 0){
        --v;
        res *= v;
    }
    return k + res;
}
