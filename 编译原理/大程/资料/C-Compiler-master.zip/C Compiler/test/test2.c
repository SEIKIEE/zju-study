int v = 10
float f(float k) {
    /*comment
    new line*/ int j = 1 + ;
    return 0.1;
}
