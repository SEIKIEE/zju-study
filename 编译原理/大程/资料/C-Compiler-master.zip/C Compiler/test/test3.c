//test for select statement and jump statement
int main()
{
	float a = 1.0, b = 2.0, c = 3.0, d = 4.0;
	if (a < b) {
		if (c < d) {
			return 1;
		}
		return 0;
	}
	return 0;
}