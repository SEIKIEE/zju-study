//test for expression
int main()
{
	
	int b = 1;
	float c = 2.0;
	int a[10];
}