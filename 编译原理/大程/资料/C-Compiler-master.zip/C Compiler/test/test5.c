//test for declaration
int a = 1, b[2], c(int d), e, f(), g(float h, int i, int j[]);

float k;
int l;
int main()
{
	int m = a;
	g(k,a,b);
}
int g(float h, int i, int j[])
{
	return 1;
}
