//test for function declaration and definition
int fact(int n);
int main()
{
	return fact(10);
}
int fact(int n)
{
	if (n == 1)
		return 1;
	else
		return n * fact(n - 1);
}