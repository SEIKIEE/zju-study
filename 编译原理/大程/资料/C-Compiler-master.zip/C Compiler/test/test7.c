//test for iteration statement, selection statement, jump statement and combination of two complex statement
int main()
{
	int fact1 = 1, fact2 = 1, fact3 = 1, a = 1, i = 0;

	for (i = 1; i <= 10; ++i)
		fact1 *= i;
	while (i <= 20) {
		for (; i <= 15; i++)
			a += i;
		if (fact3 < fact1) {
			do {
				fact3 *= 2;
				if (fact3 < i + 10)
					continue;
				i--;
			} while (i > -10);
			fact2 *= i;
			i += 1;
		}
		else 
			i = 100;
	}
	return 0;
}