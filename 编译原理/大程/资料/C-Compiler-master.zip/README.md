# C-Compiler

基于 flex 及 yacc 的 C 语法子集编译器

## 运行方式

+ 将测试文件放入 "C Compiler"/test 文件夹中，以 "test0.c", "test1.c" 此格式命名文件。
+ VS 运行，在命令行中输入相应测试文件编号。

## 语法

参见 grammar.txt 以及 parser.y。

## 中间代码格式

| 语法                  | 描述                                      |
| --------------------- | ----------------------------------------- |
| x := y [op] z         | 将变量 y 和 z 进行 op 运算的结果传递给 x  |
| x := y                | 赋值操作，将变量 y 赋值给 x               |
| x := &y               | 取地址操作，将 y 的地址赋值给 x           |
| x := *y               | 取以 y 值为地址的内存单元的内容赋给 x     |
| *x := y               | 将 y 值赋给以 x 值为地址的内存单元        |
| x := #10              | 将立即数 10 的值传递给变量 x              |
| IF x [relop] y GOTO z | 如果 x 与 y 满足[relop]关系则跳转至标号 z |
| GOTO label1           | 无条件跳转至 lable1                       |
| DEC x [size]          | 内存空间申请，大小为 size                 |
| RETURN x              | 退出当前函数并返回 x 值                   |
| RETURN                | 退出当前函数                              |
| PARAM x               | 函数形参声明                              |
| ARG x                 | 为函数传入实参 x                          |
| CALL f                | 调用函数 f                                |
| x := CALL f           | 调用函数 f，并将其返回值赋给 x            |
| x := [cast_type] y    | 类型转换                                  |

